# Phase 3: User Decisions and Consumer Evidence V1

Source: current user messages. Selected code excerpts only; not complete files, not reconstructed headers or downstream implementations. HTML entities in the message are decoded for readable C++ excerpts. Decisions are recorded separately from static code observations.

## Decisions

U02: same participation rule as TCP. If a feature returns a nonzero event mask for the session, participation is requested. Existing extension-table availability/allocation and observer registration still apply.
U03: consumers cannot modify parser result data through the supported const-reference listener API. No blanket assumption of post-callback validity is added.
U04: preserve existing fingerprint algorithm/output in this task, including verified last-suite omission. No QUIC-only fix.
U05: preserve TCP behavior. A real proven bug may justify a separate explicit correction; suspected defects are not automatic change authorization.

## C01: Enforcement event gating

```cpp
if (m_pFeatureStatusManager == nullptr || !m_pFeatureStatusManager->getFeatureStatus()) {
    return 0;
}
if (m_httpsPortsViewer == nullptr ||
    !m_httpsPortsViewer->isHttpsPort(session.getKey()->getDstPort())) {
    return 0;
}
DPPolicyItem* policy = DPSharedDoublePolicyArray::getGlobalSharedPolicyArray()->getActivePolicy(session.getPolicyId());
if (policy == nullptr || !policy->profileExists[IDS_PROFILE_TLS_ENFORCEMENT]) {
    return 0;
}
return 0b00111111;
```

## C02: Enforcement Manager pointer forwarding and synchronous evaluation

```cpp
m_detectorsPackPimpl->ruleBasedDetector.setCurrentClientHelloData(&clientHelloData);
Detector& detector = m_detectorsPackPimpl->ruleBasedDetector;
return handleEvent(detector, session, &packet, tlsData);
```

```cpp
WrongOrderDetector& detector = m_detectorsPackPimpl->wrongOrderDetector;
detector.setLastRecordSeen(&context.record);
detector.setCurrentClientHelloSupportedVersionsMask(context.currentClientHelloSupportedVersionsMask);
detector.setEarlyDataOffered(context.earlyDataOffered);
return handleEvent(detector, session, &packet, tlsData);
```

```cpp
Violation violation = detectionStrategy.detect(session, tlsData);
```

## C03: Fingerprint listener forwards only fingerprint, discards returned Action

```cpp
packetFlowManager->onParsedClientHello(session, packet, data.getFingerprint());
return TLSFeatureVerdict{};
```

## C04: Fingerprint manager accesses shared full-string viewer during callback

```cpp
const auto& fs = TLSFlow::Context::Engine::Application::getInstance().getClientHelloDataViewer()->getFullString();
if(fs.getLength() > 0)
{
    if(m_pFullStringProcessor->insert(fingerprint, fs.getData(), fs.getLength()) != IFullStringProcessor::ProcessResult::Success)
```

The insert implementation is not supplied. No assertion that insert copies bytes, retains pointers or accesses them asynchronously is made.

## C05: Visibility projection and synchronous collector chain

```cpp
m_pCollector->collect(getParams(packet, data));
```

```cpp
return {packet.getPolicyId(),
        data.getFingerprint(),
        data.getSni(),
        data.getTlsVersion(),
        packet.getPayloadDstIpAddr(),
        packet.getPayloadDstPort()};
```

Params definition and registry/recorder internals are not supplied. getParams construction alone does not prove deep-copy ownership. The shown monitor consumes parameters synchronously in collect, including SNI/fingerprint/version access and recorder calls.

## C06: Side effects are not parser-result mutation

The supplied Enforcement Manager can mitigate through mutable Session/DPFrame and reads terminalViolationMask. The supplied Fingerprint manager can set packet action, session reset/aging state and return Action::Stop; C03 discards that returned Action at the listener boundary. Preserve this current behavior. Do not infer no side effects from const result data, or invent an observer Stop that the listener did not return. Mitigation redesign is outside Phase 3.
