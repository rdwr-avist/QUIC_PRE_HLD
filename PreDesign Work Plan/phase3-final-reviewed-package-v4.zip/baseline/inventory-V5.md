# Inventory V5: Existing TLS-Flow Processing Contract

## Status and boundary

**Final Step 2 baseline for starting Step 3: semantic equivalence matrix.** This is a static inventory of the supplied current TCP path, not a completed QUIC matrix, future processing contract, Phase 3 exit PASS or readiness for Phase 4. There are 131 stable IDs, unchanged from V4. V5 corrects and expands existing rows rather than deleting IDs or creating a second numbering system.

Scope: packet/session inputs, direct state reads, processing results, errors/unsupported/continuation, observer/viewer facts, state observations, and feedback that affects further processing. Supporting wiring, storage and resource code is evidence only. No classes, architecture, traversal owner, full dispatch order, commit mechanism or pool design is selected.

## Authority

- The exact workplan governs phase scope and gates. Phase 1 is a prior research report, not automatic verified evidence or a requirement. Phase 2 remains the accepted state/attempt policy; current TCP findings do not override it.
- Every inventory row is CODE-VERIFIED in the limited sense of static inspection of the referenced declarations and branches. Runtime occurrence, production corruption and external-consumer behavior are not claimed. Evidence nature separately distinguishes wire facts, stored facts, derived/heuristic observations, software progress and declared vocabulary.
- Keep CODE-VERIFIED, PRIOR-REPORT, PHASE2-DECISION, PROPOSAL and OPEN-QUESTION separate in the matrix. The inventory does not preselect QUIC classifications.
- FRD/SRS remain explicitly deferred by the user. Requirement mapping is not claimed complete. Phase 1 is not retroactively declared PASS. The required QUIC fingerprint content remains unresolved despite raw transport-parameter inclusion in existing code; ask only for a focused excerpt or scope decision when needed.
- All three authority documents and the original code bundle are present and hash-verified. No re-upload of supplied material is needed. Earlier missing-file blockers are historical, not current blockers.

## Step 3 handoff

For every ID record: TCP source/symbol and trigger; semantic meaning and whether observed or heuristic; candidate QUIC source and extraction/reassembly; classification; semantic relation; representation differences; evidence; qualitative processing cost; and sharing implications.

Use exactly these classifications: **Shared**, **QUIC-applicable with different source/trigger**, **TCP-specific**, **Not applicable to current QUIC scope**, **Unresolved**. Separately record **Identical**, **Analogous only**, or **Different**. If no counterpart is applicable, explain that explicitly rather than fabricate a relation. Software getters, lifecycle events and enum sentinels may have no wire trigger.

Do not classify an item TCP-specific merely because its current implementation is Record-shaped. Do not create artificial QUIC Records. Distinguish available CH data, newly produced CH completion and actual callback delivery. Keep parser progress/errors, unsupported, resource outcomes and observer verdicts separate. A current defect/risk is not automatically required compatibility behavior.

Every ID must be covered. Grouped matrix rows must list all covered IDs; split facets must retain their parent ID and cover every stated fact. Current TCP completion observations P3-OBS-003/004 are heuristics, not decoded Finished messages. Unresolved matrix questions are allowed during investigation but must be dispositioned before the relevant final gates.

## Evidence coordinates

References use 1-based lines within exact extracted files, including preserved leading whitespace. Bundle line = extracted line + appendix bundle start line - 1. Anchors identify a declaration/function/branch; claims may require the full referenced body and caller. Source SHA-256 values are in the appendix and JSON. No source code or input document was changed.

## Inputs and direct state reads

### P3-IN-001 | getPayload

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** L7 payload pointer supplied at beginPacket; borrowed packet bytes.

**Evidence nature:** Supplied packet/session/state input; wire data and software metadata must be distinguished.

**Current fact:** uint8_t*: Borrowed packet payload pointer, retained as a pointer for packet processing; bytes are not copied wholesale.

Sources: `processor/include/PayloadParams.hpp:43` / `PayloadParams::getPayload`; `processor/src/Processor.cpp:93` / `Processor::captureStepPacketMetadata`.

### P3-IN-002 | getLength

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Available L7 payload byte count, computed by Conductor from frame length and offsets.

**Evidence nature:** Supplied packet/session/state input; wire data and software metadata must be distinguished.

**Current fact:** uint16_t: Payload length bounds packet-local parsing and participates in expected TCP sequence calculation.

Sources: `processor/include/PayloadParams.hpp:47` / `PayloadParams::getLength`; `processor/src/Processor.cpp:93` / `Processor::captureStepPacketMetadata`.

### P3-IN-003 | getSessionIdx

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Session index supplied by Session; no wire field is a direct substitute.

**Evidence nature:** Supplied packet/session/state input; wire data and software metadata must be distinguished.

**Current fact:** uint32_t: Session index keys continuation lookup/allocation; default constructor argument in the parameterized constructor is 0xffffffff.

Sources: `processor/include/PayloadParams.hpp:51` / `PayloadParams::getSessionIdx`; `processor/src/Processor.cpp:93` / `Processor::captureStepPacketMetadata`.

### P3-IN-004 | getTcpSeq

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** TCP sequence number plus payload length, compared with saved expected sequence using serial arithmetic.

**Evidence nature:** Supplied packet/session/state input; wire data and software metadata must be distinguished.

**Current fact:** uint32_t: TCP sequence participates in exact resume, full retransmission, overlap trimming and gap detection; default parameter is zero.

Sources: `processor/include/PayloadParams.hpp:55` / `PayloadParams::getTcpSeq`; `processor/src/Processor.cpp:93` / `Processor::captureStepPacketMetadata`.

### P3-IN-005 | TLSData input

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** const TLSData& supplied at each processRecord call; no new wire trigger.

**Evidence nature:** Supplied packet/session/state input; wire data and software metadata must be distinguished.

**Current fact:** processRecord accepts const TLSData&. Direct field reads in Processor.cpp are hsState and tlsVersionMask, not all fields of TLSData.

Sources: `processor/include/IProcessor.hpp:53` / `IProcessor::processRecord`; `processor/src/Processor.cpp:810` / `Processor::processNewRecord`.

### P3-IN-006 | hsState

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Stored hsState read during new-record and alert processing; eligibility is state-dependent.

**Evidence nature:** Supplied packet/session/state input; wire data and software metadata must be distinguished.

**Current fact:** Controls Unsupported short-circuit, handshake parsing eligibility, opaque record treatment and plaintext-alert eligibility. Alert continuation captures eligibility when started.

Sources: `processor/src/Processor.cpp:810` / `Processor::processNewRecord`; `processor/src/Processor.cpp:745` / `Processor::processAlert`; `processor/src/Processor.cpp:533` / `Processor::startSegmentedAlert`.

### P3-IN-007 | tlsVersionMask

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Stored advertised tlsVersionMask read for opaque ApplicationData classification.

**Evidence nature:** Supplied packet/session/state input; wire data and software metadata must be distinguished.

**Current fact:** isTLS13(mask) changes ApplicationData opaque-record classification while InProgress. This is an advertised-version mask, not evidence of negotiated version.

Sources: `processor/src/Processor.cpp:877` / `Processor::processNewRecord`; `common/include/TLSData.hpp:77` / `isTLS13`.

### P3-IN-008 | Session and packet identity

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Conductor supplies Session&, DPFrame&, session index and packet timestamp to consumers/state updates. Packet payload length is frame total length minus L7 offset from L2.

**Evidence nature:** Supplied packet/session/state input; wire data and software metadata must be distinguished.

**Current fact:** Conductor supplies Session&, DPFrame&, session index and packet timestamp to consumers/state updates. Packet payload length is frame total length minus L7 offset from L2.

Sources: `packet-flow/src/TLSFlowConductor.cpp:139` / `TLSFlowConductor::process`.

### P3-IN-009 | Transport/control observations

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Conductor inspects L4 protocol, SYN-without-ACK and RST-without-ACK before/around processing. These are TCP-specific observations, not QUIC equivalents.

**Evidence nature:** Supplied packet/session/state input; wire data and software metadata must be distinguished.

**Current fact:** Conductor inspects L4 protocol, SYN-without-ACK and RST-without-ACK before/around processing. These are TCP-specific observations, not QUIC equivalents.

Sources: `packet-flow/src/TLSFlowConductor.cpp:115` / `TLSFlowConductor::process`.

### P3-IN-010 | State routing

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Finished/Unsupported bypass parsing; Error/TerminatedByAlert use terminal-payload callbacks. Zero payload bypasses processing.

**Evidence nature:** Supplied packet/session/state input; wire data and software metadata must be distinguished.

**Current fact:** Finished/Unsupported bypass parsing; Error/TerminatedByAlert use terminal-payload callbacks. Zero payload bypasses processing.

Sources: `packet-flow/src/TLSFlowConductor.cpp:134` / `TLSFlowConductor::process`.

### P3-IN-011 | Session participation

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Subscriber event masks determine extension creation and observer participation; absent extension means no processor invocation.

**Evidence nature:** Supplied packet/session/state input; wire data and software metadata must be distinguished.

**Current fact:** Subscriber event masks determine extension creation and observer participation; absent extension means no processor invocation.

Sources: `packet-flow/src/TLSFlowConductor.cpp:421` / `TLSFlowConductor::buildExtension`; `packet-flow/src/TLSFlowConductor.cpp:59` / `TLSFlowConductor::onInbound`; `packet-flow/include/ITlsListener.hpp:39` / `ITlsListener::getSessionEventMask`.

## Session facts and lifecycle

### P3-STATE-001 | hsState

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Conductor record/control/unsupported/feedback decisions and reset; current stored value read before normal current-record update.

**Evidence nature:** Stored/exposed software fact; freshness and ownership must be assessed separately.

**Current fact:** Current accumulated lifecycle state, prior to normal current-record update during record/CH dispatch. Passed through const TLSData& to listener callbacks; not necessarily read by external consumers in this supplied bundle. Current HsState vocabulary is PreHandshake, InProgress, ChangeCipherSpec, Finished, Error, TerminatedByAlert, Unsupported. isActiveHandshakeState selects the first three; isSilentTerminalState selects Finished/Unsupported; usesTerminalPayloadPath selects Error/TerminatedByAlert. These are current-code predicates, not changes to Phase 2 policy.

Sources: `common/include/TLSData.hpp:104` / `TLSData::hsState`; `packet-flow/include/ITlsListener.hpp:44` / `ITlsListener callback TLSData`.

### P3-STATE-002 | tlsVersionMask

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Completed CH normal update replaces mask from CH viewer; reset clears it.

**Evidence nature:** Stored/exposed software fact; freshness and ownership must be assessed separately.

**Current fact:** Advertised-version mask accumulated from completed CH; also used for alert classification. Passed through const TLSData& to listener callbacks; not necessarily read by external consumers in this supplied bundle.

Sources: `common/include/TLSData.hpp:55` / `TLSData::tlsVersionMask`; `packet-flow/include/ITlsListener.hpp:44` / `ITlsListener callback TLSData`; `packet-flow/src/TLSFlowConductor.cpp:501` / `TLSFlowConductor::updateTLSDataOnClientHello`.

### P3-STATE-003 | clientHelloCount

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Complete CH normal update increments count; reset clears it.

**Evidence nature:** Stored/exposed software fact; freshness and ownership must be assessed separately.

**Current fact:** uint8_t clientHelloCount increments on a completed CH normal update and is reset with TLSData. It is a bounded stored counter, not an unbounded monotonic count. It gates CCS/ApplicationData handling through the exact zero/nonzero predicate. Exposed through const TLSData&; external field reads are not proven by this bundle.

Sources: `common/include/TLSData.hpp:106` / `TLSData::clientHelloCount`; `packet-flow/include/ITlsListener.hpp:44` / `ITlsListener callback TLSData`; `packet-flow/src/TLSFlowConductor.cpp:501` / `TLSFlowConductor::updateTLSDataOnClientHello`.

### P3-STATE-004 | earlyDataCount

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Normal ApplicationData update with clientHelloCount == 0; reset clears uint8_t counter.

**Evidence nature:** Stored/exposed software fact; freshness and ownership must be assessed separately.

**Current fact:** uint8_t earlyDataCount increments on the normal ApplicationData update when clientHelloCount == 0; it is not independently verified proof that no CH ever occurred. Exposed through const TLSData& to callbacks; external field reads are not proven by this bundle.

Sources: `common/include/TLSData.hpp:107` / `TLSData::earlyDataCount`; `packet-flow/include/ITlsListener.hpp:44` / `ITlsListener callback TLSData`; `packet-flow/src/TLSFlowConductor.cpp:530` / `TLSFlowConductor::updateTLSDataOnApplicationData`.

### P3-STATE-005 | earlyDataOffered

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Complete CH normal update copies current CH early_data flag; reset clears it.

**Evidence nature:** Stored/exposed software fact; freshness and ownership must be assessed separately.

**Current fact:** Committed CH early_data presence; affects TCP TLS13 completion heuristic. Passed through const TLSData& to listener callbacks; not necessarily read by external consumers in this supplied bundle.

Sources: `common/include/TLSData.hpp:108` / `TLSData::earlyDataOffered`; `packet-flow/include/ITlsListener.hpp:44` / `ITlsListener callback TLSData`; `packet-flow/src/TLSFlowConductor.cpp:501` / `TLSFlowConductor::updateTLSDataOnClientHello`.

### P3-STATE-006 | preCcsSeen

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Normal CCS update with clientHelloCount == 0; reset clears uint8_t counter.

**Evidence nature:** Stored/exposed software fact; freshness and ownership must be assessed separately.

**Current fact:** uint8_t preCcsSeen increments on the normal CCS update when clientHelloCount == 0. Exposed through const TLSData& to callbacks; external field reads are not proven by this bundle.

Sources: `common/include/TLSData.hpp:109` / `TLSData::preCcsSeen`; `packet-flow/include/ITlsListener.hpp:44` / `ITlsListener callback TLSData`; `packet-flow/src/TLSFlowConductor.cpp:521` / `TLSFlowConductor::updateTLSDataOnChangeCipherSpec`.

### P3-STATE-007 | chFingerprint

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Complete CH normal update copies fingerprint from viewer; reset defaults it.

**Evidence nature:** Stored/exposed software fact; freshness and ownership must be assessed separately.

**Current fact:** Value copy of completed CH fingerprint. Passed through const TLSData& to listener callbacks; not necessarily read by external consumers in this supplied bundle.

Sources: `common/include/TLSData.hpp:110` / `TLSData::chFingerprint`; `packet-flow/include/ITlsListener.hpp:44` / `ITlsListener callback TLSData`; `packet-flow/src/TLSFlowConductor.cpp:501` / `TLSFlowConductor::updateTLSDataOnClientHello`.

### P3-STATE-008 | terminalViolationMask

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Existing listener feedback commits OR mask; reset clears it. This is software feedback, not a wire field.

**Evidence nature:** Stored/exposed software fact; freshness and ownership must be assessed separately.

**Current fact:** Accumulated existing feedback metadata; affects SYN reuse gating. No feature policy is defined here. Passed through const TLSData& to listener callbacks; not necessarily read by external consumers in this supplied bundle.

Sources: `common/include/TLSData.hpp:111` / `TLSData::terminalViolationMask`; `packet-flow/include/ITlsListener.hpp:44` / `ITlsListener callback TLSData`; `packet-flow/src/TLSFlowConductor.cpp:567` / `TLSFlowConductor::commitViolation`.

### P3-STATE-009 | clientHelloTimeStamp

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Complete CH normal update copies session last-packet timestamp; reset clears it.

**Evidence nature:** Stored/exposed software fact; freshness and ownership must be assessed separately.

**Current fact:** Packet timestamp of last committed completed CH. Passed through const TLSData& to listener callbacks; not necessarily read by external consumers in this supplied bundle.

Sources: `common/include/TLSData.hpp:112` / `TLSData::clientHelloTimeStamp`; `packet-flow/include/ITlsListener.hpp:44` / `ITlsListener callback TLSData`; `packet-flow/src/TLSFlowConductor.cpp:501` / `TLSFlowConductor::updateTLSDataOnClientHello`.

### P3-STATE-010 | TLSData defaults/reset

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** RST no-mask path, extension reset/release/reuse or direct clear/reset operation; no mandatory TLS wire message.

**Evidence nature:** Stored/exposed software fact; freshness and ownership must be assessed separately.

**Current fact:** clear() restores PreHandshake and zero/false/default values for every field; existing RST path may invoke it. This does not redefine Phase 2 attempt reset. TLSSessionExtension owns TLSData and returns references to it. resetValue replaces it with defaults and clears observer lists. Table release resets and erases the extension; allocation can reclaim an eligible victim. Borrowed callback TLSData references must not be treated as stable snapshots after reset/release/reuse. markReclaimable alone is not immediate release.

Sources: `common/include/TLSData.hpp:151` / `TLSData::clear`; `packet-flow/src/TLSFlowConductor.cpp:128` / `TLSFlowConductor::process`; `extension/include/TLSSessionExtension.hpp:49` / `TLSSessionExtension::resetValue`; `extension/include/TLSSessionExtensionTable.hpp:124` / `TLSSessionExtensionTable::release`; `extension/include/TLSSessionExtensionTable.hpp:61` / `TLSSessionExtensionTable::alloc`.

## Public results and CH status

### P3-OUT-001 | RecordParsed

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** processSingleRecord final ContinueProcessing -> RecordParsed.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** RecordParsed is the public translation of the final internal ContinueProcessing result. Conductor enters current-record analysis. It does not prove a completed ClientHello, a fresh CH event, successful observer delivery, or a state update; those have separate guards and feedback.

Sources: `processor/include/IProcessor.hpp:33` / `IProcessor::TLSStepResult`; `processor/src/Processor.cpp:210` / `Processor::processRecord`; `packet-flow/src/TLSFlowConductor.cpp:167` / `TLSFlowConductor::dispatchStepResult`.

### P3-OUT-002 | NeedMoreData

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Final Segmented result or nonempty full-continuation retransmission -> NeedMoreData.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Translation of Segmented, or a full continuation retransmission when bytes remain. Conductor returns Continue but stops its record loop because result is not RecordParsed.

Sources: `processor/include/IProcessor.hpp:34` / `IProcessor::TLSStepResult`; `processor/src/Processor.cpp:210` / `Processor::processRecord`; `packet-flow/src/TLSFlowConductor.cpp:167` / `TLSFlowConductor::dispatchStepResult`.

### P3-OUT-003 | Unsupported

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Continuation gap flag, or final unsupported CH reconstruction outcome -> Unsupported.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Translation of unsupported reconstruction or continuation gap. Distinct from ParsingError::UnsupportedRecordType and UnsupportedTlsVersion, which lead to Stop.

Sources: `processor/include/IProcessor.hpp:35` / `IProcessor::TLSStepResult`; `processor/src/Processor.cpp:210` / `Processor::processRecord`; `packet-flow/src/TLSFlowConductor.cpp:167` / `TLSFlowConductor::dispatchStepResult`.

### P3-OUT-004 | EndOfPacket

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** No remaining packet bytes, or final internal EndOfPacket -> EndOfPacket.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** No remaining bytes, or internal EndOfPacket (including Unsupported state short-circuit). No current-record dispatch.

Sources: `processor/include/IProcessor.hpp:36` / `IProcessor::TLSStepResult`; `processor/src/Processor.cpp:210` / `Processor::processRecord`; `packet-flow/src/TLSFlowConductor.cpp:167` / `TLSFlowConductor::dispatchStepResult`.

### P3-OUT-005 | Stop

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Uninitialized packet step, final Error/StopProcessing or default translation -> Stop.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Translation of Error/StopProcessing/default or an uninitialized step. Conductor consults getLastError; Stop is not itself an observer Stop or an Error state transition.

Sources: `processor/include/IProcessor.hpp:37` / `IProcessor::TLSStepResult`; `processor/src/Processor.cpp:210` / `Processor::processRecord`; `packet-flow/src/TLSFlowConductor.cpp:167` / `TLSFlowConductor::dispatchStepResult`.

### P3-OUT-006 | Internal result translation

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** processSingleRecord final return reaches processRecord translation; nested returns may be overridden by caller branches.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** ContinueProcessing/Segmented/Unsupported/Error/EndOfPacket/StopProcessing are internal RecordProcessResult values. processRecord translates the result returned by processSingleRecord: ContinueProcessing -> RecordParsed; Segmented -> NeedMoreData; Unsupported -> Unsupported; EndOfPacket -> EndOfPacket; Error and StopProcessing -> Stop. This is the final translation, not a guarantee that every nested return propagates unchanged. In particular processNewRecord returns Segmented for an incomplete record before returning its innerProcessResult; see P3-ERR-019 for the cipher soft-stop path.

Sources: `processor/src/Processor.hpp:32` / `Processor::RecordProcessResult`; `processor/src/Processor.cpp:210` / `Processor::processRecord`; `processor/src/Processor.cpp:1072` / `Processor::processNewRecord`.

### P3-OUT-007 | ClientHello status None

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** CH status reset to None by ordinary packet reset; resume may bypass reset.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** None is the canonical CH viewer status when no CH has been recognized in the current reset context. It is a stored status, not an independent processing result or wire observation. It is reset by resetStepState; resume paths can bypass that reset.

Sources: `processor/include/IClientHelloDataViewer.hpp:25` / `IClientHelloDataViewer::ClientHelloParsingStatus`; `packet-flow/src/TLSFlowConductor.cpp:195` / `TLSFlowConductor::analyzeProcessResult`; `packet-flow/src/TLSFlowConductor.cpp:554` / `TLSFlowConductor::commitUnsupported`.

### P3-OUT-008 | ClientHello status Partial

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** CH recognition or unfinished CH extension continuation sets Partial.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Partial is set when CH processing starts and during extension continuation before completion. It can coexist with NeedMoreData, Unsupported or Stop. It is not proof that resumable continuation exists. Conductor uses Partial in the InProgress Unsupported disposition guard.

Sources: `processor/include/IClientHelloDataViewer.hpp:26` / `IClientHelloDataViewer::ClientHelloParsingStatus`; `packet-flow/src/TLSFlowConductor.cpp:195` / `TLSFlowConductor::analyzeProcessResult`; `packet-flow/src/TLSFlowConductor.cpp:554` / `TLSFlowConductor::commitUnsupported`.

### P3-OUT-009 | ClientHello status Complete

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** CH digest finalization/completion sets Complete before record-capacity check; no guaranteed callback follows.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Explicit viewer status, not an additional public step result or a fresh-event token. Complete is checked for CH callback eligibility and normal state update; Partial is checked in unsupported handling. None is not a completed result. Both ordinary and continuation CH completion set Complete before checking record-viewer capacity. Capacity failure can then produce public Stop while Complete remains visible. Stop dispatch handles the parsing-error channel and does not invoke the normal CH callback. Thus parser completion, successful RecordParsed delivery, and a newly delivered CH observation are distinct.

Sources: `processor/include/IClientHelloDataViewer.hpp:27` / `IClientHelloDataViewer::ClientHelloParsingStatus`; `packet-flow/src/TLSFlowConductor.cpp:195` / `TLSFlowConductor::analyzeProcessResult`; `packet-flow/src/TLSFlowConductor.cpp:554` / `TLSFlowConductor::commitUnsupported`; `processor/src/Processor.cpp:1051` / `Processor::processNewRecord`; `processor/src/Processor.cpp:473` / `Processor::processSegmentedClientHelloContinuation`; `packet-flow/src/TLSFlowConductor.cpp:167` / `TLSFlowConductor::dispatchStepResult`.

### P3-OUT-010 | Last error channel

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** getLastError reads canonical error after processing; no new wire trigger from the getter itself.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** getLastError returns stored m_lastError separately from step result. None suppresses anomaly callback. Error state is not automatic merely because parsing returned Stop.

Sources: `processor/src/Processor.cpp:1664` / `Processor::getLastError`; `packet-flow/src/TLSFlowConductor.cpp:268` / `TLSFlowConductor::checkForParsingError`; `packet-flow/src/TLSFlowConductor.cpp:167` / `TLSFlowConductor::dispatchStepResult`.

## Errors and soft stops

### P3-ERR-001 | None

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Reset/no-error sentinel read; no malformed-wire trigger is implied.

**Evidence nature:** No-error sentinel; not a failure or a fresh observation.

**Current fact:** No-error sentinel.

Sources: `processor/include/ParsingError.hpp:14` / `ParsingError::None`; `processor/src/Processor.cpp:120` / `m_lastError assignment None`.

### P3-ERR-002 | UnsupportedTlsVersion

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Condition for UnsupportedTlsVersion: Assigned in Processor.cpp at extracted-file lines 929. Trigger: a ClientHello record reaches the supported-record-version check and tlsRecord::isSupportedVersion() is false; returns Error/public Stop. This error name is not the public Unsupported result.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Assigned in Processor.cpp at extracted-file lines 929. Trigger: a ClientHello record reaches the supported-record-version check and tlsRecord::isSupportedVersion() is false; returns Error/public Stop. This error name is not the public Unsupported result.

Sources: `processor/include/ParsingError.hpp:15` / `ParsingError::UnsupportedTlsVersion`; `processor/src/Processor.cpp:929` / `m_lastError assignment UnsupportedTlsVersion`.

### P3-ERR-003 | MalformedTlsRecord

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Condition for MalformedTlsRecord: Assigned in Processor.cpp at extracted-file lines 631, 658, 1548. Triggers: TLS record-header parse is non-Complete (new record or reconstructed alert), or reconstructed alert bytes received exceed the declared total record length (header plus payload). These return Error/public Stop.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Assigned in Processor.cpp at extracted-file lines 631, 658, 1548. Triggers: TLS record-header parse is non-Complete (new record or reconstructed alert), or reconstructed alert bytes received exceed the declared total record length (header plus payload). These return Error/public Stop.

Sources: `processor/include/ParsingError.hpp:16` / `ParsingError::MalformedTlsRecord`; `processor/src/Processor.cpp:631` / `m_lastError assignment MalformedTlsRecord`.

### P3-ERR-004 | UnsupportedRecordType

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Condition for UnsupportedRecordType: Assigned in Processor.cpp at extracted-file lines 638, 1561. Trigger: the TLS record parser reports an unsupported record type, including reconstructed alert handling. Returns StopProcessing/public Stop, not public Unsupported.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Assigned in Processor.cpp at extracted-file lines 638, 1561. Trigger: the TLS record parser reports an unsupported record type, including reconstructed alert handling. Returns StopProcessing/public Stop, not public Unsupported.

Sources: `processor/include/ParsingError.hpp:17` / `ParsingError::UnsupportedRecordType`; `processor/src/Processor.cpp:638` / `m_lastError assignment UnsupportedRecordType`.

### P3-ERR-005 | RecordLengthExceedsData

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Condition for RecordLengthExceedsData: Assigned in Processor.cpp at extracted-file lines 646, 1555. Trigger: declared TLS record payload exceeds MaxTlsRecordPayloadSize, including reconstructed alert handling. Returns Error/public Stop; the name does not mean every incomplete packet is an error.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Assigned in Processor.cpp at extracted-file lines 646, 1555. Trigger: declared TLS record payload exceeds MaxTlsRecordPayloadSize, including reconstructed alert handling. Returns Error/public Stop; the name does not mean every incomplete packet is an error.

Sources: `processor/include/ParsingError.hpp:18` / `ParsingError::RecordLengthExceedsData`; `processor/src/Processor.cpp:646` / `m_lastError assignment RecordLengthExceedsData`.

### P3-ERR-006 | HandshakeLengthNotMatchingRecordLength

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Condition for HandshakeLengthNotMatchingRecordLength: Assigned in Processor.cpp at extracted-file lines 943, 979. Triggers: handshake length plus header is smaller than the TLS record payload; or it remains larger after CH prefix/body parsing without the recordLevelFragmented Unsupported branch. Returns StopProcessing/public Stop. Record-level fragmentation is a distinct Unsupported path.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Assigned in Processor.cpp at extracted-file lines 943, 979. Triggers: handshake length plus header is smaller than the TLS record payload; or it remains larger after CH prefix/body parsing without the recordLevelFragmented Unsupported branch. Returns StopProcessing/public Stop. Record-level fragmentation is a distinct Unsupported path.

Sources: `processor/include/ParsingError.hpp:19` / `ParsingError::HandshakeLengthNotMatchingRecordLength`; `processor/src/Processor.cpp:943` / `m_lastError assignment HandshakeLengthNotMatchingRecordLength`.

### P3-ERR-007 | MalformedHandshake

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Condition for MalformedHandshake: Assigned in Processor.cpp at extracted-file lines 1533. Trigger: handshake-header parser returns non-Complete; returns Error/public Stop.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Assigned in Processor.cpp at extracted-file lines 1533. Trigger: handshake-header parser returns non-Complete; returns Error/public Stop.

Sources: `processor/include/ParsingError.hpp:20` / `ParsingError::MalformedHandshake`; `processor/src/Processor.cpp:1533` / `m_lastError assignment MalformedHandshake`.

### P3-ERR-008 | MalformedClientHello

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** No demonstrated runtime producer/wire trigger in supplied Processor; declaration/sentinel only.

**Evidence nature:** Declared vocabulary/sentinel only; no demonstrated producer.

**Current fact:** Declared vocabulary only: no direct assignment in supplied Processor.cpp. Do not invent a reachable producer.

Sources: `processor/include/ParsingError.hpp:21` / `ParsingError::MalformedClientHello`.

### P3-ERR-009 | ClientHelloBodyInvalid

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Condition for ClientHelloBodyInvalid: Assigned in Processor.cpp at extracted-file lines 1515. Trigger: CH parser non-Complete not accepted by the incomplete-status Unsupported or extension-continuation branches; includes Failure. Returns Error/public Stop. See P3-PARSE-002 through P3-PARSE-005.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Assigned in Processor.cpp at extracted-file lines 1515. Trigger: CH parser non-Complete not accepted by the incomplete-status Unsupported or extension-continuation branches; includes Failure. Returns Error/public Stop. See P3-PARSE-002 through P3-PARSE-005.

Sources: `processor/include/ParsingError.hpp:22` / `ParsingError::ClientHelloBodyInvalid`; `processor/src/Processor.cpp:1515` / `m_lastError assignment ClientHelloBodyInvalid`.

### P3-ERR-010 | MultipleClientHello

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Condition for MultipleClientHello: Assigned in Processor.cpp at extracted-file lines 951. Trigger: a new CH is encountered while the canonical CH status is already Complete in the active processing context; returns Error/public Stop. It is not a session-wide ban; see P3-FB-009.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Assigned in Processor.cpp at extracted-file lines 951. Trigger: a new CH is encountered while the canonical CH status is already Complete in the active processing context; returns Error/public Stop. It is not a session-wide ban; see P3-FB-009.

Sources: `processor/include/ParsingError.hpp:23` / `ParsingError::MultipleClientHello`; `processor/src/Processor.cpp:951` / `m_lastError assignment MultipleClientHello`.

### P3-ERR-011 | ExtensionsLengthExceedsData

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** No demonstrated runtime producer/wire trigger in supplied Processor; declaration/sentinel only.

**Evidence nature:** Declared vocabulary/sentinel only; no demonstrated producer.

**Current fact:** Declared vocabulary only: no direct assignment in supplied Processor.cpp. Do not invent a reachable producer.

Sources: `processor/include/ParsingError.hpp:24` / `ParsingError::ExtensionsLengthExceedsData`.

### P3-ERR-012 | ExtensionParsingFailure

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Condition for ExtensionParsingFailure: Assigned in Processor.cpp at extracted-file lines 1154, 1176, 1300, 1340, 1376, 1379, 1387. Triggers: invalid processExtensions state; SNI parser non-Complete; supported_versions or supported_groups parser failure; extension parser non-Complete; or consumed-length mismatch. Returns Error/public Stop. Dedicated MalformedSniExtension checks are separate.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Assigned in Processor.cpp at extracted-file lines 1154, 1176, 1300, 1340, 1376, 1379, 1387. Triggers: invalid processExtensions state; SNI parser non-Complete; supported_versions or supported_groups parser failure; extension parser non-Complete; or consumed-length mismatch. Returns Error/public Stop. Dedicated MalformedSniExtension checks are separate.

Sources: `processor/include/ParsingError.hpp:25` / `ParsingError::ExtensionParsingFailure`; `processor/src/Processor.cpp:1154` / `m_lastError assignment ExtensionParsingFailure`.

### P3-ERR-013 | MalformedSniExtension

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Condition for MalformedSniExtension: processSni assigns MalformedSniExtension when parsed SNI count is zero or greater than two, when the first host_name length is zero or greater than max_sni_length (255), or when strnlen(name, length) differs from the declared length. It returns Error/public Stop. A non-host_name first entry returns ContinueProcessing without setting the parsed-SNI flag; a parser failure instead uses ExtensionParsingFailure.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** processSni assigns MalformedSniExtension when parsed SNI count is zero or greater than two, when the first host_name length is zero or greater than max_sni_length (255), or when strnlen(name, length) differs from the declared length. It returns Error/public Stop. A non-host_name first entry returns ContinueProcessing without setting the parsed-SNI flag; a parser failure instead uses ExtensionParsingFailure.

Sources: `processor/include/ParsingError.hpp:26` / `ParsingError::MalformedSniExtension`; `processor/src/Processor.cpp:1184` / `m_lastError assignment MalformedSniExtension`.

### P3-ERR-014 | CipherParsingFailure

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Condition for CipherParsingFailure: Assigned in Processor.cpp at extracted-file lines 1433. Trigger: cipher-suite parser returns non-Complete for a nonzero cipher list; returns Error, immediately propagated by processNewRecord and translated to public Stop. Distinct from the cipher soft-stop path in P3-ERR-019.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Assigned in Processor.cpp at extracted-file lines 1433. Trigger: cipher-suite parser returns non-Complete for a nonzero cipher list; returns Error, immediately propagated by processNewRecord and translated to public Stop. Distinct from the cipher soft-stop path in P3-ERR-019.

Sources: `processor/include/ParsingError.hpp:27` / `ParsingError::CipherParsingFailure`; `processor/src/Processor.cpp:1433` / `m_lastError assignment CipherParsingFailure`.

### P3-ERR-015 | SegmentBufferAllocationFailure

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Condition for SegmentBufferAllocationFailure: Assigned when prepareSegmentBufferForContinuation fails for alert alignment, alert reassembly, opaque tracking or CH extension continuation. Returns StopProcessing/public Stop. Preparation can fail because an existing buffer has a conflicting continuation mode or because allocation/session registration fails; this is not proof of malformed wire data or specifically memory exhaustion.

**Evidence nature:** Buffer-preparation failure: resource or conflicting continuation-state outcome, not evidence of malformed TLS.

**Current fact:** Assigned when prepareSegmentBufferForContinuation fails for alert alignment, alert reassembly, opaque tracking or CH extension continuation. Returns StopProcessing/public Stop. Preparation can fail because an existing buffer has a conflicting continuation mode or because allocation/session registration fails; this is not proof of malformed wire data or specifically memory exhaustion.

Sources: `processor/include/ParsingError.hpp:28` / `ParsingError::SegmentBufferAllocationFailure`; `processor/src/Processor.cpp:792` / `m_lastError assignment SegmentBufferAllocationFailure`; `processor/src/Processor.cpp:326` / `Processor::prepareSegmentBufferForContinuation`.

### P3-ERR-016 | SegmentMismatch

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Condition for SegmentMismatch: Assigned in Processor.cpp at extracted-file lines 1119, 1129. Triggers in FirstSegment extension copying: total extensions length is smaller than continuation nextLength, or calculated bytes to copy exceed m_lengthLeftToParse. The buffer is deallocated and StopProcessing/public Stop is returned.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Assigned in Processor.cpp at extracted-file lines 1119, 1129. Triggers in FirstSegment extension copying: total extensions length is smaller than continuation nextLength, or calculated bytes to copy exceed m_lengthLeftToParse. The buffer is deallocated and StopProcessing/public Stop is returned.

Sources: `processor/include/ParsingError.hpp:29` / `ParsingError::SegmentMismatch`; `processor/src/Processor.cpp:1119` / `m_lastError assignment SegmentMismatch`.

### P3-ERR-017 | RecordsExceedDataViewerCapacity

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Condition for RecordsExceedDataViewerCapacity: Assigned when adding a current/completed record would exceed maxRecords, at Processor.cpp extracted-file lines 483, 524, 736 and 1061; returns StopProcessing, translated to public Stop. CH completion at lines 475 and 1052 precedes its capacity check, so Complete can coexist with this failed current step. Record insertion and normal CH delivery are not guaranteed. This is a result-validity distinction, not a new state policy.

**Evidence nature:** Record-viewer capacity failure; resource-limit outcome, not malformed TLS.

**Current fact:** Assigned when adding a current/completed record would exceed maxRecords, at Processor.cpp extracted-file lines 483, 524, 736 and 1061; returns StopProcessing, translated to public Stop. CH completion at lines 475 and 1052 precedes its capacity check, so Complete can coexist with this failed current step. Record insertion and normal CH delivery are not guaranteed. This is a result-validity distinction, not a new state policy.

Sources: `processor/include/ParsingError.hpp:30` / `ParsingError::RecordsExceedDataViewerCapacity`; `processor/src/Processor.cpp:483` / `m_lastError assignment RecordsExceedDataViewerCapacity`; `processor/src/Processor.cpp:473` / `Processor::processSegmentedClientHelloContinuation`; `processor/src/Processor.cpp:1051` / `Processor::processNewRecord`; `packet-flow/src/TLSFlowConductor.cpp:167` / `TLSFlowConductor::dispatchStepResult`.

### P3-ERR-018 | MaxParsingErrorValue

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** No demonstrated runtime producer/wire trigger in supplied Processor; declaration/sentinel only.

**Evidence nature:** Declared vocabulary/sentinel only; no demonstrated producer.

**Current fact:** Enum sentinel, not a runtime error outcome.

Sources: `processor/include/ParsingError.hpp:32` / `ParsingError::MaxParsingErrorValue`.

### P3-ERR-019 | Soft stops without dedicated error

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Condition for Soft stops without dedicated error: Digest append/calculate failure and extension-locator capacity failure can return local StopProcessing without assigning a dedicated ParsingError. Do not equate public Stop with a non-None error. Cipher-specific propagation: processNewRecord immediately propagates only Error from processCiphers; other non-ContinueProcessing results skip extension processing and remain in innerProcessResult. After the record-capacity check and record insertion, an incomplete record returns Segmented (public NeedMoreData), whereas a complete record returns the retained StopProcessing (public Stop). A capacity failure can instead override the outcome with RecordsExceedDataViewerCapacity/Stop. No normal RecordParsed delivery is implied by the cipher soft stop. These are static branch facts, not measured runtime occurrences or approved code fixes.

**Evidence nature:** Local capacity/digest soft stop; final progress result depends on caller branches.

**Current fact:** Digest append/calculate failure and extension-locator capacity failure can return local StopProcessing without assigning a dedicated ParsingError. Do not equate public Stop with a non-None error. Cipher-specific propagation: processNewRecord immediately propagates only Error from processCiphers; other non-ContinueProcessing results skip extension processing and remain in innerProcessResult. After the record-capacity check and record insertion, an incomplete record returns Segmented (public NeedMoreData), whereas a complete record returns the retained StopProcessing (public Stop). A capacity failure can instead override the outcome with RecordsExceedDataViewerCapacity/Stop. No normal RecordParsed delivery is implied by the cipher soft stop. These are static branch facts, not measured runtime occurrences or approved code fixes.

Sources: `processor/src/Processor.cpp:1221` / `Processor::feedExtensionsFP`; `processor/src/Processor.cpp:1394` / `Processor::parseAllExtensions`; `processor/src/Md5Digest.cpp:21` / `Md5Digest::calculate`; `processor/src/Processor.cpp:1422` / `Processor::processCiphers`; `processor/src/Processor.cpp:1005` / `Processor::processNewRecord`; `processor/src/Processor.cpp:1060` / `Processor::processNewRecord`; `processor/src/Processor.cpp:210` / `Processor::processRecord`.

## Continuation and resource boundaries

### P3-CONT-001 | None

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Continuation mode None; alignment-only state can still be retained.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** No explicit reassembly mode; a stored alert alignment offset can still exist.

Sources: `processor/include/IProcessor.hpp:23` / `IProcessor::ContinuationMode`; `processor/src/Processor.cpp:406` / `Processor::processSingleRecord`; `processor/src/SegmentBuffer.hpp:23` / `SegmentBuffer::ContinuationMode`.

### P3-CONT-002 | OpaqueRecordTracking

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Incomplete state-eligible opaque record starts remaining-byte tracking.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Tracks remaining record bytes and saved record shape without interpreting opaque content.

Sources: `processor/include/IProcessor.hpp:24` / `IProcessor::ContinuationMode`; `processor/src/Processor.cpp:406` / `Processor::processSingleRecord`; `processor/src/SegmentBuffer.hpp:24` / `SegmentBuffer::ContinuationMode`.

### P3-CONT-003 | ClientHelloExtensionReassembly

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** CH parser IncompleteExtensionSection, accepted continuation branch and successful preparation.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Reconstructs extension section after the CH prefix/body is already available.

Sources: `processor/include/IProcessor.hpp:25` / `IProcessor::ContinuationMode`; `processor/src/Processor.cpp:406` / `Processor::processSingleRecord`; `processor/src/SegmentBuffer.hpp:25` / `SegmentBuffer::ContinuationMode`.

### P3-CONT-004 | AlertRecordReassembly

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Incomplete alert header or alert payload starts alert reassembly.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Tracks split alert header/payload and preserves plaintext eligibility/alignment.

Sources: `processor/include/IProcessor.hpp:26` / `IProcessor::ContinuationMode`; `processor/src/Processor.cpp:406` / `Processor::processSingleRecord`; `processor/src/SegmentBuffer.hpp:26` / `SegmentBuffer::ContinuationMode`.

### P3-CONT-005 | Gap flag

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Pending buffer sequence relation reaches the gap branch; isContinuationGap exposes the flag.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** isContinuationGap exposes packet-local continuation gap. Conductor uses it to decide Unsupported state handling.

Sources: `processor/src/Processor.cpp:128` / `Processor::resumeOrDiscardStepContinuation`; `processor/src/Processor.cpp:1086` / `Processor::processExtensions`.

### P3-CONT-006 | Sequence cases

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** TCP start/end sequence compared with saved expected sequence using serial comparisons.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Exact expected sequence resumes; end <= expected under serial arithmetic is full retransmission; overlap crossing expected trims old bytes; remaining case is gap and discards stored continuation.

Sources: `processor/src/Processor.cpp:128` / `Processor::resumeOrDiscardStepContinuation`; `processor/src/Processor.cpp:1086` / `Processor::processExtensions`.

### P3-CONT-007 | Session-scoped continuation

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Session-index lookup selects saved continuation and rebinds Processor storage pointers.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Continuation access is keyed by session index, while Processor viewers are instance-local mutable members. Saved state includes remaining lengths, record/handshake types, cipher/compression counts, lastVersion, digest and alert metadata. On CH continuation the code restores cipher/compression counts and lastVersion; it does not restore every canonical CH fact. In particular supported-version mask/parsed flag are not restored here, and the fallback reads the shared parser version. Do not equate session-scoped buffer ownership with complete session-scoped viewer freshness. See P3-VIEW-003 and P3-VIEW-014.

Sources: `processor/src/Processor.cpp:265` / `Processor::resumeStepFromSegmentBuffer`; `processor/src/Processor.cpp:1086` / `Processor::processExtensions`; `processor/src/Processor.cpp:432` / `Processor::processSegmentedClientHelloContinuation`; `processor/src/Processor.cpp:466` / `Processor::processSegmentedClientHelloContinuation`.

### P3-CONT-008 | Continuation completion

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Saved remaining bytes reach completion; parsing/feeding and capacity guards still determine delivered result.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** CH/opaque/alert continuation reconstructs current record metadata on completion, but public RecordParsed and observer delivery require subsequent parsing/feeding and record-capacity checks to succeed. A CH can already be Complete when capacity failure produces Stop. Successful completion may leave bytes for another step; finishSegmentBufferContinuation can retain alert alignment state. No unconditional emission or delivery is guaranteed.

Sources: `processor/src/Processor.cpp:384` / `Processor::finishSegmentBufferContinuation`; `processor/src/Processor.cpp:1086` / `Processor::processExtensions`.

### P3-CONT-009 | CH reconstruction boundary

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** CH parser incomplete status, handshake/record length relation or extension reassembly size bound.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Incomplete prefix/body in a segmented CH is Unsupported; incomplete extensions can be continued. Cross-record CH fragmentation is Unsupported; oversized extension reassembly is Unsupported.

Sources: `processor/src/Processor.cpp:1456` / `Processor::processClientHello`; `processor/src/Processor.cpp:1086` / `Processor::processExtensions`.

### P3-CONT-010 | Continuation mode exposure

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** getContinuationMode reads packet-local m_stepContinuationMode; getter has no independent wire trigger.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** getContinuationMode returns m_stepContinuationMode. Conductor currently consumes isContinuationGap, not getContinuationMode. The field is not proven to be a canonical live-buffer mode at every instant.

Sources: `processor/src/Processor.hpp:57` / `Processor::getContinuationMode`; `processor/src/Processor.cpp:56` / `Processor::beginPacket`; `processor/src/Processor.cpp:533` / `Processor::startSegmentedAlert`.

### P3-CONT-011 | Resource/lifecycle loss

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Continuation allocation/access/deallocation, full-map eviction, session aging or capacity checks; not a unique wire message.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** SegmentBufferManager may evict oldest entry on full capacity; allocation/access/deallocation have boolean outcomes, aging erases entry. No explicit eviction result is returned through IProcessor. Record as current behavior, not a proposed pool design or violation policy. Existing continuation map capacity is MaxNumberOfSegmentBuffers=1000. SegmentBufferSize=3000 bounds the CH extension reassembly branch; ExtensionsArray::add has its own 1024-locator bound, not the separate declared MaxNumberOfLocators=100. Record viewer capacity is 128 and digest storage is 2870 bytes with a strict append rejection at total >= capacity. These are different limits with different result paths; they are not a proposed QUIC allocation design. Allocation failure does not promise transactional rollback: the manager inserts before checking the new session, and the session-not-found branch returns false without erasing that insertion.

Sources: `processor/src/SegmentBufferManager.cpp:23` / `SegmentBufferManager::allocate`; `processor/src/SegmentBufferManager.cpp:108` / `SegmentBufferManager::onEvent`; `processor/include/Definitions.hpp:18` / `SegmentBufferSize/MaxNumberOfSegmentBuffers`; `processor/src/SegmentBufferManager.hpp:25` / `SegmentBufferManager map capacity`; `processor/src/ExtensionsSorting.hpp:118` / `ExtensionsArray::maxSupportedExtensions`; `processor/src/Processor.hpp:127` / `Processor::maxRecords`; `processor/src/Md5Digest.hpp:37` / `Md5Digest::s_max_buffer_size`.

## Record-shaped data and contexts

### P3-REC-001 | recordType

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** TLS record header type byte, or saved type reconstructed on continuation completion.

**Evidence nature:** Observed wire metadata or software projection; record shape is representation, not a transport-sharing verdict.

**Current fact:** Raw uint8_t TLS record type; predicates identify handshake/CCS/alert/ApplicationData.

Sources: `processor/include/Record.hpp:10` / `Record::recordType`; `processor/src/Processor.cpp:745` / `Processor::processAlert`.

### P3-REC-002 | handshakeType

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Handshake header type byte only when handshake parsing runs; otherwise default/saved metadata.

**Evidence nature:** Observed wire metadata or software projection; record shape is representation, not a transport-sharing verdict.

**Current fact:** Raw uint8_t handshake type, populated only when handshake parsing runs; opaque handshake may retain default/saved value.

Sources: `processor/include/Record.hpp:11` / `Record::handshakeType`; `processor/src/Processor.cpp:745` / `Processor::processAlert`.

### P3-REC-003 | recordLength

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** TLS record header declared payload length, or saved length reconstructed on continuation completion.

**Evidence nature:** Observed wire metadata or software projection; record shape is representation, not a transport-sharing verdict.

**Current fact:** uint16_t record payload length, excluding TLS record header.

Sources: `processor/include/Record.hpp:12` / `Record::recordLength`; `processor/src/Processor.cpp:745` / `Processor::processAlert`.

### P3-REC-004 | alertLevel

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Two-byte readable plaintext alert parser produces level.

**Evidence nature:** Observed wire metadata or software projection; record shape is representation, not a transport-sharing verdict.

**Current fact:** Alert level, meaningful only with readableAlert.

Sources: `processor/include/Record.hpp:13` / `Record::alertLevel`; `processor/src/Processor.cpp:745` / `Processor::processAlert`.

### P3-REC-005 | alertDescription

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Two-byte readable plaintext alert parser produces description.

**Evidence nature:** Observed wire metadata or software projection; record shape is representation, not a transport-sharing verdict.

**Current fact:** Alert description, meaningful only with readableAlert.

Sources: `processor/include/Record.hpp:14` / `Record::alertDescription`; `processor/src/Processor.cpp:745` / `Processor::processAlert`.

### P3-REC-006 | readableAlert

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Alert record, plaintext eligibility, zero alignment offset and two-byte parse conditions produce readableAlert.

**Evidence nature:** Observed wire metadata or software projection; record shape is representation, not a transport-sharing verdict.

**Current fact:** Validity discriminator; requires plaintext-eligible state, alignment and exactly two alert bytes in current parsing path.

Sources: `processor/include/Record.hpp:15` / `Record::readableAlert`; `processor/src/Processor.cpp:745` / `Processor::processAlert`.

### P3-REC-007 | getLastRecord

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** getLastRecord borrows canonical m_record after current step; getter is not a wire event.

**Evidence nature:** Observed wire metadata or software projection; record shape is representation, not a transport-sharing verdict.

**Current fact:** Returns const reference to mutable canonical m_record; Conductor consumes it per RecordParsed.

Sources: `processor/include/IRecordsDataViewer.hpp:18` / `IRecordsDataViewer::getLastRecord`; `processor/src/Processor.cpp:1640` / `Processor::getLastRecord`.

### P3-REC-008 | getAllRecords

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** getAllRecords borrows bounded records pushed by processing; getter is not a whole-packet completion event.

**Evidence nature:** Observed wire metadata or software projection; record shape is representation, not a transport-sharing verdict.

**Current fact:** Returns const reference to bounded m_records collection; capacity 128. Contains records pushed during current/reset-or-resume context, not a guaranteed whole-packet immutable batch.

Sources: `processor/include/IRecordsDataViewer.hpp:16` / `IRecordsDataViewer::getAllRecords`; `processor/src/Processor.cpp:1635` / `Processor::getAllRecords`.

### P3-REC-009 | getRecordType

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** getRecordType copies canonical current record type; no new wire trigger.

**Evidence nature:** Observed wire metadata or software projection; record shape is representation, not a transport-sharing verdict.

**Current fact:** Scalar copy of current m_record.recordType.

Sources: `processor/include/IRecordsDataViewer.hpp:19` / `IRecordsDataViewer::getRecordType`; `processor/src/Processor.cpp:1648` / `Processor::getRecordType`.

### P3-REC-010 | getRecordLength

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** getRecordLength copies canonical current record length; no new wire trigger.

**Evidence nature:** Observed wire metadata or software projection; record shape is representation, not a transport-sharing verdict.

**Current fact:** Scalar copy of current m_record.recordLength.

Sources: `processor/include/IRecordsDataViewer.hpp:20` / `IRecordsDataViewer::getRecordLength`; `processor/src/Processor.cpp:1653` / `Processor::getRecordLength`.

### P3-REC-011 | TLSRecordContext::record

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Conductor builds current TLSRecordContext borrowing getLastRecord on RecordParsed analysis.

**Evidence nature:** Observed wire metadata or software projection; record shape is representation, not a transport-sharing verdict.

**Current fact:** Borrowed const Record& valid during current-record dispatch, per header contract.

Sources: `packet-flow/include/TLSRecordContext.hpp:13` / `TLSRecordContext::record`; `packet-flow/src/TLSFlowConductor.cpp:195` / `TLSFlowConductor::analyzeProcessResult`.

### P3-REC-012 | TLSRecordContext::currentClientHelloSupportedVersionsMask

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Conductor reads supported-version viewer only if current record.isClientHello(); otherwise zero.

**Evidence nature:** Observed wire metadata or software projection; record shape is representation, not a transport-sharing verdict.

**Current fact:** Current CH mask for CH-shaped record; zero otherwise.

Sources: `packet-flow/include/TLSRecordContext.hpp:22` / `TLSRecordContext::currentClientHelloSupportedVersionsMask`; `packet-flow/src/TLSFlowConductor.cpp:195` / `TLSFlowConductor::analyzeProcessResult`.

### P3-REC-013 | TLSRecordContext::earlyDataOffered

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Conductor reads early-data viewer only if current record.isClientHello(); otherwise false.

**Evidence nature:** Observed wire metadata or software projection; record shape is representation, not a transport-sharing verdict.

**Current fact:** Current CH early-data flag for CH-shaped record; false otherwise.

Sources: `packet-flow/include/TLSRecordContext.hpp:23` / `TLSRecordContext::earlyDataOffered`; `packet-flow/src/TLSFlowConductor.cpp:195` / `TLSFlowConductor::analyzeProcessResult`.

### P3-REC-014 | TLSRecordContext::alertTerminating

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Readable alert record plus stored advertised-version mask invokes isTerminatingAlert.

**Evidence nature:** Observed wire metadata or software projection; record shape is representation, not a transport-sharing verdict.

**Current fact:** Conductor-derived bool from committed version mask and readable alert fields; defaults false.

Sources: `packet-flow/include/TLSRecordContext.hpp:24` / `TLSRecordContext::alertTerminating`; `packet-flow/src/TLSFlowConductor.cpp:195` / `TLSFlowConductor::analyzeProcessResult`.

## Viewers, freshness and lifetime

### P3-VIEW-001 | getFingerprint

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** CH digest finalization produces m_fp; getter copies retained value without a fresh-event discriminator.

**Evidence nature:** Stored/exposed software fact; freshness and ownership must be assessed separately.

**Current fact:** Value copy of canonical m_fp; no per-call success bool.

Sources: `processor/include/IClientHelloDataViewer.hpp:35` / `IClientHelloDataViewer::getFingerprint`; `processor/src/Processor.cpp:1591` / `Processor::getFingerprint`.

### P3-VIEW-002 | getSni

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** SNI extension parsing/validation sets copied Sni and parsed flag; getter tests flag.

**Evidence nature:** Stored/exposed software fact; freshness and ownership must be assessed separately.

**Current fact:** Copies canonical Sni only if parsed flag is true; returns false otherwise. Conductor ignores bool and supplies default empty Sni. The first host_name is validated and copied into owned Sni storage; the boolean distinguishes unavailable/non-host_name SNI from a successful value. This availability is not represented separately in ClientHelloData.

Sources: `processor/include/IClientHelloDataViewer.hpp:43` / `IClientHelloDataViewer::getSni`; `processor/src/Processor.cpp:1596` / `Processor::getSni`; `processor/src/Processor.cpp:1169` / `Processor::processSni`.

### P3-VIEW-003 | getSupportedVersionBitMask

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** supported_versions feeding ORs version bits, or CH wire-version fallback when parsed flag is false.

**Evidence nature:** Stored/exposed software fact; freshness and ownership must be assessed separately.

**Current fact:** Advertised mask from supported_versions, with CH wire-version fallback when absent. feedSuppVersionsFP ORs versions into m_supportedVersionsBitMask and sets m_supportedVersionsParsed; ordinary reset clears both, but beginPacket resume bypasses that reset. CH continuation restores lastVersion from its buffer, yet its fallback uses the shared ClientHello parser getVersion() when m_supportedVersionsParsed is false. Session-scoped continuation therefore does not itself prove current-session mask freshness. This is a static interleaving risk, not a verified runtime corruption.

Sources: `processor/include/IClientHelloDataViewer.hpp:51` / `IClientHelloDataViewer::getSupportedVersionBitMask`; `processor/src/Processor.cpp:1581` / `Processor::getSupportedVersionBitMask`; `processor/src/Processor.cpp:56` / `Processor::beginPacket`; `processor/src/Processor.cpp:258` / `Processor::clearStepClientHelloValues`; `processor/src/Processor.cpp:432` / `Processor::processSegmentedClientHelloContinuation`; `processor/src/Processor.cpp:466` / `Processor::processSegmentedClientHelloContinuation`; `processor/src/Processor.cpp:1294` / `Processor::feedSuppVersionsFP`.

### P3-VIEW-004 | isEarlyDataOffered

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** parseAllExtensions encounters early_data type; getter reads retained flag.

**Evidence nature:** Stored/exposed software fact; freshness and ownership must be assessed separately.

**Current fact:** Presence of early_data extension, not observed early-data packets.

Sources: `processor/include/IClientHelloDataViewer.hpp:56` / `IClientHelloDataViewer::isEarlyDataOffered`; `processor/src/Processor.cpp:1586` / `Processor::isEarlyDataOffered`.

### P3-VIEW-005 | getFullString

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Digest append/finalization constructs byte buffer; getter returns borrowed pointer/length, not a new CH event.

**Evidence nature:** Stored/exposed software fact; freshness and ownership must be assessed separately.

**Current fact:** Borrowed pointer and length into active digest buffer, not an owned string.

Sources: `processor/include/IClientHelloDataViewer.hpp:61` / `IClientHelloDataViewer::getFullString`; `processor/src/Processor.cpp:1607` / `Processor::getFullString`.

### P3-VIEW-006 | getTlsVersion

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Record version before CH, CH wire version, or first non-GREASE supported version updates lastVersion.

**Evidence nature:** Stored/exposed software fact; freshness and ownership must be assessed separately.

**Current fact:** lastVersion; may start from record version, then CH version, then first non-GREASE supported version.

Sources: `processor/include/IClientHelloDataViewer.hpp:70` / `IClientHelloDataViewer::getTlsVersion`; `processor/src/Processor.cpp:1576` / `Processor::getTlsVersion`.

### P3-VIEW-007 | getCipherCount

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Successful cipher parsing sets count; continuation restores saved count.

**Evidence nature:** Stored/exposed software fact; freshness and ownership must be assessed separately.

**Current fact:** Parsed cipher count, not necessarily count of bytes actually fed to digest.

Sources: `processor/include/IClientHelloDataViewer.hpp:79` / `IClientHelloDataViewer::getCipherCount`; `processor/src/Processor.cpp:1612` / `Processor::getCipherCount`.

### P3-VIEW-008 | getExtensionCount

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Successful locator collection/sort sets count.

**Evidence nature:** Stored/exposed software fact; freshness and ownership must be assessed separately.

**Current fact:** Count of collected extension locators.

Sources: `processor/include/IClientHelloDataViewer.hpp:89` / `IClientHelloDataViewer::getExtensionCount`; `processor/src/Processor.cpp:1617` / `Processor::getExtensionCount`.

### P3-VIEW-009 | getCompressionCount

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** CH body parsing sets compression count; continuation restores saved count.

**Evidence nature:** Stored/exposed software fact; freshness and ownership must be assessed separately.

**Current fact:** CH compression length/count.

Sources: `processor/include/IClientHelloDataViewer.hpp:98` / `IClientHelloDataViewer::getCompressionCount`; `processor/src/Processor.cpp:1622` / `Processor::getCompressionCount`.

### P3-VIEW-010 | isSegmented

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** ProcessorState changes at continuation start/resume/completion; getter compares it to SingleSegment.

**Evidence nature:** Stored/exposed software fact; freshness and ownership must be assessed separately.

**Current fact:** Computed as ProcessorState != SingleSegment; completion resets to SingleSegment, so not durable historical segmentation metadata.

Sources: `processor/include/IClientHelloDataViewer.hpp:100` / `IClientHelloDataViewer::isSegmented`; `processor/src/Processor.cpp:1627` / `Processor::isSegmented`.

### P3-VIEW-011 | getClientHelloParsingStatus

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** CH recognition/continuation/completion or packet reset changes canonical status.

**Evidence nature:** Stored/exposed software fact; freshness and ownership must be assessed separately.

**Current fact:** Canonical status persists across record steps until reset/updated; it is not a fresh-event discriminator. Complete can remain visible after record-capacity failure returns Stop, since it is set before the capacity check. Normal CH callback delivery requires the RecordParsed analysis path and applicable feedback; the Stop path does not dispatch that callback. See P3-OUT-009 and P3-FB-008.

Sources: `processor/include/IClientHelloDataViewer.hpp:109` / `IClientHelloDataViewer::getClientHelloParsingStatus`; `processor/src/Processor.cpp:1659` / `Processor::getClientHelloParsingStatus`; `processor/src/Processor.cpp:1051` / `Processor::processNewRecord`; `processor/src/Processor.cpp:473` / `Processor::processSegmentedClientHelloContinuation`; `packet-flow/src/TLSFlowConductor.cpp:167` / `TLSFlowConductor::dispatchStepResult`.

### P3-VIEW-012 | Parsing-error viewer

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** IParsingErrorViewer getter reads stored error; no independent wire trigger.

**Evidence nature:** Stored/exposed software fact; freshness and ownership must be assessed separately.

**Current fact:** IParsingErrorViewer::getLastError exposes canonical error by value, not per-record owned result.

Sources: `processor/include/IParsingErrorViewer.hpp:16` / `IParsingErrorViewer::getLastError`; `processor/src/Processor.cpp:1664` / `Processor::getLastError`.

### P3-VIEW-013 | Shared instance wiring

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Factory init injects one Processor instance into all viewer interfaces; software initialization, not a wire event.

**Evidence nature:** Stored/exposed software fact; freshness and ownership must be assessed separately.

**Current fact:** Factory injects the same Processor instance as IProcessor, CH viewer, record viewer and error viewer, and exposes those interfaces publicly. Results are not per-session immutable viewer objects.

Sources: `context/engine/src/Factory.cpp:44` / `Factory::init`; `context/engine/src/Factory.cpp:51` / `Factory::getProcessorViewer`.

### P3-VIEW-014 | Reset/freshness boundary

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** beginPacket reset versus resumed early-return branch; later processRecord calls do not automatically reset CH facts.

**Evidence nature:** Stored/exposed software fact; freshness and ownership must be assessed separately.

**Current fact:** beginPacket resets ordinary new-packet CH/viewer/error state through resetStepState. A resumed path returns early and clears only the record collection/current record for non-retransmission/non-gap resume. There is no automatic per-record reset of CH Complete. resumeStepFromSegmentBuffer rebinds buffer/digest/locators and selects continuation mode, but does not restore/reset every canonical CH field. Supported-version mask and parsed flag, early-data/SNI facts and other shared viewer fields must not be assumed session-owned merely because continuation storage is keyed by session. See P3-VIEW-003 for the concrete version-mask/fallback dependency and P3-CONT-007 for the limited saved CH fields.

Sources: `processor/src/Processor.cpp:56` / `Processor::beginPacket`; `processor/src/Processor.cpp:104` / `Processor::resetStepState`; `processor/src/Processor.cpp:210` / `Processor::processRecord`; `processor/src/Processor.cpp:265` / `Processor::resumeStepFromSegmentBuffer`; `processor/src/Processor.cpp:432` / `Processor::processSegmentedClientHelloContinuation`; `processor/src/Processor.cpp:1294` / `Processor::feedSuppVersionsFP`.

### P3-VIEW-015 | Digest lifetime

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** CH digest init/append, continuation digest copy, active-pointer rebinding and later storage reuse.

**Evidence nature:** Stored/exposed software fact; freshness and ownership must be assessed separately.

**Current fact:** getFullString borrows active digest storage. CH continuation copies digest to initial storage before finishing continuation; cleanup resets active pointers, and later CH digest init/calculate overwrites contents. Pointer identity and freshness are not session ownership.

Sources: `processor/src/Processor.cpp:1607` / `Processor::getFullString`; `processor/src/Processor.cpp:473` / `Processor::processSegmentedClientHelloContinuation`; `processor/src/Processor.cpp:305` / `Processor::resetContinuationPointers`; `processor/src/Md5Digest.cpp:15` / `Md5Digest::init`.

## Existing fingerprint computation

### P3-FP-001 | Existing composition

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Existing composition: CH wire fields or local digest/normalization operation described below.

**Evidence nature:** Derived fingerprint computation over observed CH bytes; current implementation, not a product requirement.

**Current fact:** Existing feed path hashes CH wire version, cipher values and sorted extension types; selected extension lengths/content are included. This inventories actual implementation, not a new fingerprint requirement.

Sources: `processor/src/Processor.cpp:983` / `Processor::processNewRecord`; `processor/src/Processor.cpp:1422` / `Processor::processCiphers`; `processor/src/Processor.cpp:1221` / `Processor::feedExtensionsFP`.

### P3-FP-002 | QUIC transport parameter content

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** QUIC transport parameter content: CH wire fields or local digest/normalization operation described below.

**Evidence nature:** Derived fingerprint computation over observed CH bytes; current implementation, not a product requirement.

**Current fact:** isExtensionContentIncludedInFp explicitly includes quic_transport_parameters and draft type; feedExtensionsFP default branch hashes raw extension content after type/length. This is code evidence, not resolution of the deferred QUIC product requirement.

Sources: `processor/src/Processor.hpp:234` / `Processor::isExtensionContentIncludedInFp`; `processor/src/Processor.cpp:1274` / `Processor::feedExtensionsFP`.

### P3-FP-003 | Normalization/sorting

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Normalization/sorting: CH wire fields or local digest/normalization operation described below.

**Evidence nature:** Derived fingerprint computation over observed CH bytes; current implementation, not a product requirement.

**Current fact:** Extension type is deGrease-normalized; locators sort with comparator by type/length/value. Supported versions/groups use specialized deGrease feeding. Preserve exact comparator semantics, not comments alone.

Sources: `processor/src/Processor.cpp:1392` / `Processor::parseAllExtensions`; `processor/src/ExtensionsSorting.hpp:63` / `ExtensionLocator::extensionsSortingComparison`; `processor/src/Processor.cpp:1294` / `Processor::feedSuppVersionsFP`; `processor/src/Processor.cpp:1333` / `Processor::feedSuppGroupsFP`.

### P3-FP-004 | Digest capacity/failure

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Digest capacity/failure: CH wire fields or local digest/normalization operation described below.

**Evidence nature:** Derived fingerprint computation over observed CH bytes; current implementation, not a product requirement.

**Current fact:** Md5Digest.calculate rejects zero length or len + current index >= 2870-byte array size; failure can stop processing without a dedicated error. finalize computes MD5 over accumulated bytes. The local failure must be traced through its caller: cipher feeding can become NeedMoreData on an incomplete record or Stop on a complete record, subject to the record-capacity check; see P3-ERR-019. Other feeding failures must not be assigned that cipher-specific path automatically.

Sources: `processor/src/Md5Digest.cpp:21` / `Md5Digest::calculate`; `processor/src/Md5Digest.hpp:37` / `Md5Digest::s_max_buffer_size`; `processor/src/Processor.cpp:1005` / `Processor::processNewRecord`; `processor/src/Processor.cpp:1072` / `Processor::processNewRecord`.

### P3-FP-005 | Cipher feeding loop detail

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Cipher feeding loop detail: CH wire fields or local digest/normalization operation described below.

**Evidence nature:** Derived fingerprint computation over observed CH bytes; current implementation, not a product requirement.

**Current fact:** processCiphers uses for (int i = 0; cipherSuitesLen -= 2; i++). For an even nonzero validated length, the last suite is not fed by this loop. Do not replace actual behavior with an assumption that all counted suites are hashed; no repair is made here.

Sources: `processor/src/Processor.cpp:1440` / `Processor::processCiphers`.

## Current transition observations

### P3-OBS-001 | Completed CH

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Completed CH status on a CH-shaped record, successful normal update path, packet timestamp.

**Evidence nature:** Derived state/control decision from observed input and stored context; exact guards apply.

**Current fact:** On the normal-update path for a CH-shaped record, Complete status permits count increment and replacement of timestamp, fingerprint, version mask and early-data flag. PreHandshake becomes InProgress. Complete alone is not sufficient: step delivery, current record shape and observer feedback can prevent this update.

Sources: `packet-flow/src/TLSFlowConductor.cpp:501` / `TLSFlowConductor::updateTLSDataOnClientHello`.

### P3-OBS-002 | CCS

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** CCS-shaped record plus committed CH count, version mask and hsState.

**Evidence nature:** Derived state/control decision from observed input and stored context; exact guards apply.

**Current fact:** On the normal-update path for a CCS-shaped record, clientHelloCount == 0 increments preCcsSeen; otherwise a non-TLS13 mask with InProgress changes state to ChangeCipherSpec. The zero-count predicate is a stored uint8_t counter check, not independently verified absence of every earlier CH.

Sources: `packet-flow/src/TLSFlowConductor.cpp:521` / `TLSFlowConductor::updateTLSDataOnChangeCipherSpec`.

### P3-OBS-003 | Handshake after CCS

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Handshake-shaped record while stored hsState is ChangeCipherSpec; no decoded TLS Finished is required by current code.

**Evidence nature:** Heuristic completion inference from record shape and prior state, not direct observation of TLS Finished.

**Current fact:** On the normal-update path, a handshake-shaped record while stored hsState is ChangeCipherSpec changes state to Finished. The encrypted TLS Finished content is not decoded to prove this; this is a completion heuristic, subject to feedback allowing normal update.

Sources: `packet-flow/src/TLSFlowConductor.cpp:469` / `TLSFlowConductor::commitNormalCurrentRecord`.

### P3-OBS-004 | ApplicationData

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** ApplicationData-shaped record plus CH count, advertised TLS13 bit, InProgress and !earlyDataOffered; no decoded TLS Finished is observed.

**Evidence nature:** Heuristic completion inference from record shape and prior state, not direct observation of TLS Finished.

**Current fact:** On the normal-update path for ApplicationData, clientHelloCount == 0 increments earlyDataCount. Otherwise an advertised TLS13 bit with InProgress and !earlyDataOffered changes state to Finished. This is the current TCP completion heuristic, not a decoded Finished observation.

Sources: `packet-flow/src/TLSFlowConductor.cpp:530` / `TLSFlowConductor::updateTLSDataOnApplicationData`.

### P3-OBS-005 | Readable terminating alert

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Alert-shaped record, readableAlert, derived alertTerminating and active hsState.

**Evidence nature:** Derived state/control decision from observed input and stored context; exact guards apply.

**Current fact:** Active state + alert record + readableAlert + alertTerminating -> TerminatedByAlert.

Sources: `packet-flow/src/TLSFlowConductor.cpp:541` / `TLSFlowConductor::updateTLSDataOnAlert`.

### P3-OBS-006 | Unsupported disposition

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Public Unsupported plus continuation-gap flag, hsState and CH Partial status.

**Evidence nature:** Derived state/control decision from observed input and stored context; exact guards apply.

**Current fact:** Gap, PreHandshake, or InProgress with Partial CH -> Unsupported. Public Unsupported alone does not imply unconditional state transition.

Sources: `packet-flow/src/TLSFlowConductor.cpp:554` / `TLSFlowConductor::commitUnsupported`.

### P3-OBS-007 | TCP reset

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** TCP RST accepted by existing legal-RST predicate with no legal ACK, plus listener feedback.

**Evidence nature:** Derived state/control decision from observed input and stored context; exact guards apply.

**Current fact:** RST without ACK triggers callback; no violation mask clears TLSData even if dispatch Stop. Nonzero mask updates existing feedback state.

Sources: `packet-flow/src/TLSFlowConductor.cpp:109` / `TLSFlowConductor::process`.

### P3-OBS-008 | TCP session reuse observation

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** TCP SYN-without-ACK predicate plus active-state/violation metadata test.

**Evidence nature:** Derived state/control decision from observed input and stored context; exact guards apply.

**Current fact:** For a TCP SYN-without-ACK predicate, an existing active extension with no recorded violation is preserved. An existing extension failing that test is released and rebuilt; if no extension exists, creation is attempted directly. This is current TCP entry behavior, not Phase 2 QUIC attempt policy.

Sources: `packet-flow/src/TLSFlowConductor.cpp:74` / `TLSFlowConductor::prepareInboundExtension`.

### P3-OBS-009 | Finished reclamation observation

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Normal-update transition into Finished calls markReclaimable; software lifecycle attempt, not an independent wire event.

**Evidence nature:** Derived state/control decision from observed input and stored context; exact guards apply.

**Current fact:** After a normal current-record state change into Finished, Conductor calls markReclaimable when the extension table exists. The method returns bool, but the caller ignores it; successful marking is not guaranteed by this call. Marking does not immediately release the extension. This is existing lifecycle evidence, not pool design.

Sources: `packet-flow/src/TLSFlowConductor.cpp:195` / `TLSFlowConductor::analyzeProcessResult`; `extension/include/TLSSessionExtensionTable.hpp:136` / `TLSSessionExtensionTable::markReclaimable`.

### P3-OBS-010 | Alert terminal classifier

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Readable alert level/description plus advertised-version mask; derived terminal classification.

**Evidence nature:** Derived state/control decision from observed input and stored context; exact guards apply.

**Current fact:** Existing helper rejects invalid levels; close_notify is terminal; TLS13-only excludes user_canceled; TLS12-or-less-only uses fatal level; mixed/unknown mask uses fatal except user_canceled. Inventory of helper behavior only, not independent protocol verification.

Sources: `common/include/TLSAlert.hpp:14` / `isTerminatingAlert`.

## Observer facts and projections

### P3-CB-001 | onTLSRecord

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** RecordParsed analysis invokes onTLSRecord with current record context before normal state update.

**Evidence nature:** Delivered callback observation; delivery cardinality is not automatically wire-event cardinality.

**Current fact:** Receives Session&, DPFrame&, borrowed TLSRecordContext and const TLSData& before normal update.

Sources: `packet-flow/include/ITlsListener.hpp:64` / `ITlsListener::onTLSRecord`; `packet-flow/src/TLSFlowConductor.cpp:320` / `TLSFlowConductor callback onTLSRecord`.

### P3-CB-002 | onClientHello

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** RecordParsed analysis and retained CH status Complete, subject to feedback; not necessarily a new CH-shaped record.

**Evidence nature:** Delivered callback observation; delivery cardinality is not automatically wire-event cardinality.

**Current fact:** onClientHello receives Session&, DPFrame&, a stack-local ClientHelloData projection and const TLSData&. ClientHelloData stores const references to the stack-local fingerprint and Sni values created in onClientHello; it does not own copies of those values. Its TLS version is a converted Misc::TLSVersion, and its three counts are uint16_t constructor fields fed by uint32_t viewer getters. These references must not be treated as valid after the synchronous callback returns; retaining the projection by value does not make the referents owned. Callback eligibility is retained Complete status on RecordParsed analysis, not a fresh-event token or necessarily a CH-shaped current record.

Sources: `packet-flow/include/ITlsListener.hpp:44` / `ITlsListener::onClientHello`; `packet-flow/src/TLSFlowConductor.cpp:307` / `TLSFlowConductor callback onClientHello`; `packet-flow/include/ClientHelloData.hpp:35` / `ClientHelloData constructor and reference fields`.

### P3-CB-003 | onParsingError

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Non-None stored parsing error and subscribed anomaly listeners on analysis/Stop path.

**Evidence nature:** Delivered callback observation; delivery cardinality is not automatically wire-event cardinality.

**Current fact:** Receives error by value plus Session&, DPFrame&, const TLSData&; called only for non-None error and nonempty anomaly observers.

Sources: `packet-flow/include/ITlsListener.hpp:49` / `ITlsListener::onParsingError`; `packet-flow/src/TLSFlowConductor.cpp:282` / `TLSFlowConductor callback onParsingError`.

### P3-CB-004 | onTCPReset

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Observed TCP reset control predicate.

**Evidence nature:** Delivered callback observation; delivery cardinality is not automatically wire-event cardinality.

**Current fact:** Receives Session&, DPFrame&, const TLSData& for observed TCP reset.

Sources: `packet-flow/include/ITlsListener.hpp:54` / `ITlsListener::onTCPReset`; `packet-flow/src/TLSFlowConductor.cpp:117` / `TLSFlowConductor callback onTCPReset`.

### P3-CB-005 | onSessionEnd

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Session aging event before extension release; no required wire trigger.

**Evidence nature:** Delivered callback observation; delivery cardinality is not automatically wire-event cardinality.

**Current fact:** Receives Session&, const TLSData& during aging before extension release; notify result is ignored by onAging.

Sources: `packet-flow/include/ITlsListener.hpp:59` / `ITlsListener::onSessionEnd`; `packet-flow/src/TLSFlowConductor.cpp:359` / `TLSFlowConductor callback onSessionEnd`.

### P3-CB-006 | onTerminalPayload

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Nonempty payload while stored state uses terminal-payload path; parsing is bypassed.

**Evidence nature:** Delivered callback observation; delivery cardinality is not automatically wire-event cardinality.

**Current fact:** Receives Session&, DPFrame&, const TLSData& without processor parsing in Error/TerminatedByAlert path.

Sources: `packet-flow/include/ITlsListener.hpp:69` / `ITlsListener::onTerminalPayload`; `packet-flow/src/TLSFlowConductor.cpp:336` / `TLSFlowConductor callback onTerminalPayload`.

## Feedback and further processing

### P3-FB-001 | Step-by-step state feedback

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Software control point Step-by-step state feedback; exact listener/step/state condition is detailed below. No independent wire trigger.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Conductor calls processRecord(tlsData), dispatches current result, then checks updated active state before another call. No explicit accept/commit callback is passed to Processor; feedback is control flow and next-call state.

Sources: `packet-flow/src/TLSFlowConductor.cpp:109` / `TLSFlowConductor::process`.

### P3-FB-002 | Observer feedback shape

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Software control point Observer feedback shape; exact listener/step/state condition is detailed below. No independent wire trigger.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** TLSFeatureVerdict carries independent Dispatch Continue/Stop and violationMask. These are not parser results, packet-drop instructions or automatic Error transitions.

Sources: `packet-flow/include/TLSFeatureVerdict.hpp:12` / `TLSFeatureVerdict`.

### P3-FB-003 | Within-list STOP

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Software control point Within-list STOP; exact listener/step/state condition is detailed below. No independent wire trigger.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** notify accumulates existing mask metadata and stops the current observer list immediately on Dispatch::Stop; expired weak observers are skipped.

Sources: `packet-flow/src/TLSFlowConductor.hpp:102` / `TLSFlowConductor::notify`.

### P3-FB-004 | Across-stage STOP without mask

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Software control point Across-stage STOP without mask; exact listener/step/state condition is detailed below. No independent wire trigger.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** analyzeProcessResult sets sawStop and can still run later stages/current normal update when Stop has no accumulated mask. It returns Stop after current processing; next record is not processed.

Sources: `packet-flow/src/TLSFlowConductor.cpp:195` / `TLSFlowConductor::analyzeProcessResult`.

### P3-FB-005 | Feedback that suppresses normal update

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Software control point Feedback that suppresses normal update; exact listener/step/state condition is detailed below. No independent wire trigger.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Nonzero accumulated mask suppresses normal current-record update. Combined Stop causes Error; mask without Stop records metadata without state change. Existing boundary behavior only, no policy design.

Sources: `packet-flow/src/TLSFlowConductor.cpp:195` / `TLSFlowConductor::analyzeProcessResult`.

### P3-FB-006 | Parser STOP handling

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Software control point Parser STOP handling; exact listener/step/state condition is detailed below. No independent wire trigger.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Public Stop runs parsing-error observers only. With no non-None error or no observers, verdict is default Continue; outer record loop still ends because result is Stop.

Sources: `packet-flow/src/TLSFlowConductor.cpp:167` / `TLSFlowConductor::dispatchStepResult`.

### P3-FB-007 | State gate after record

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Software control point State gate after record; exact listener/step/state condition is detailed below. No independent wire trigger.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Even RecordParsed does not guarantee another call: observer Stop returns immediately; non-active updated state ends loop. Remaining bytes can be left unprocessed.

Sources: `packet-flow/src/TLSFlowConductor.cpp:109` / `TLSFlowConductor::process`.

### P3-FB-008 | CH callback cardinality coupling

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Software control point CH callback cardinality coupling; exact listener/step/state condition is detailed below. No independent wire trigger.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** CH callback condition tests Complete status, not record.isClientHello(). Complete persists across later steps. Thus a later RecordParsed non-CH record in the same packet can trigger another CH callback with retained CH facts, if prior feedback/state permits reaching it. Record context CH fields are still zero/false for that non-CH record. This is reachable code behavior, not an endorsed contract.

Sources: `packet-flow/src/TLSFlowConductor.cpp:240` / `TLSFlowConductor::analyzeProcessResult`; `processor/src/Processor.cpp:210` / `Processor::processRecord`; `processor/src/Processor.cpp:104` / `Processor::resetStepState`.

### P3-FB-009 | Multiple CH scope

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** Software control point Multiple CH scope; exact listener/step/state condition is detailed below. No independent wire trigger.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Processor rejects a new CH when its canonical status is already Complete. Ordinary beginPacket resets status; this is not an unconditional prohibition on a second CH across the whole session. Do not import it as Phase 2 attempt policy.

Sources: `processor/src/Processor.cpp:950` / `Processor::processNewRecord`; `processor/src/Processor.cpp:104` / `Processor::resetStepState`.

## Internal parser status translations

### P3-PARSE-001 | IClientHelloParser::Status::Complete

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** IClientHelloParser::Status::Complete returned by the corresponding internal parser call; conditional translation is detailed below.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Internal ClientHello parser Complete means the CH prefix/body parse returned Complete. processClientHello advances its record-local pointer by consumed bytes and returns ContinueProcessing. This is not yet a completed fingerprint or a public RecordParsed result: processNewRecord still applies handshake/record-length checks, version/cipher/extension feeding, completion and capacity checks. Those later operations may yield Unsupported, Stop, or continuation. See P3-OUT-006 and P3-OUT-009.

Sources: `processor/src/ITLSParser.hpp:60` / `IClientHelloParser::Status`; `processor/src/Processor.cpp:1456` / `Processor::processClientHello`; `processor/src/Processor.cpp:971` / `Processor::processNewRecord`.

### P3-PARSE-002 | IClientHelloParser::Status::IncompleteClientHelloPrefix

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** IClientHelloParser::Status::IncompleteClientHelloPrefix returned by the corresponding internal parser call; conditional translation is detailed below.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Internal CH parser status. If recordLevelFragmented is true, processClientHello returns Unsupported before starting continuation. Otherwise, if m_currentRecordIsSegmented is true, it returns Unsupported for the incomplete prefix/body. If neither condition holds, it assigns ClientHelloBodyInvalid and returns Error. The caller propagates these outcomes: Unsupported -> public Unsupported; Error -> public Stop. Neither incomplete prefix nor incomplete body is accepted as extension-only continuation.

Sources: `processor/src/ITLSParser.hpp:60` / `IClientHelloParser::Status`; `processor/src/Processor.cpp:1456` / `Processor::processClientHello`; `processor/src/Processor.cpp:1464` / `Processor::processClientHello`; `processor/src/Processor.cpp:1505` / `Processor::processClientHello`; `processor/src/Processor.cpp:210` / `Processor::processRecord`.

### P3-PARSE-003 | IClientHelloParser::Status::IncompleteClientHelloBody

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** IClientHelloParser::Status::IncompleteClientHelloBody returned by the corresponding internal parser call; conditional translation is detailed below.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Internal CH parser status. If recordLevelFragmented is true, processClientHello returns Unsupported before starting continuation. Otherwise, if m_currentRecordIsSegmented is true, it returns Unsupported for the incomplete prefix/body. If neither condition holds, it assigns ClientHelloBodyInvalid and returns Error. The caller propagates these outcomes: Unsupported -> public Unsupported; Error -> public Stop. Neither incomplete prefix nor incomplete body is accepted as extension-only continuation.

Sources: `processor/src/ITLSParser.hpp:60` / `IClientHelloParser::Status`; `processor/src/Processor.cpp:1456` / `Processor::processClientHello`; `processor/src/Processor.cpp:1464` / `Processor::processClientHello`; `processor/src/Processor.cpp:1505` / `Processor::processClientHello`; `processor/src/Processor.cpp:210` / `Processor::processRecord`.

### P3-PARSE-004 | IClientHelloParser::Status::IncompleteExtensionSection

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** IClientHelloParser::Status::IncompleteExtensionSection returned by the corresponding internal parser call; conditional translation is detailed below.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Internal CH parser status. recordLevelFragmented first yields Unsupported/public Unsupported. Otherwise processClientHello attempts ClientHelloExtensionReassembly allocation; allocation failure sets SegmentBufferAllocationFailure and returns StopProcessing/public Stop. Success selects FirstSegment, records continuation metadata, advances by consumed prefix/body bytes and returns ContinueProcessing locally. The caller still checks handshake/record length and performs feeding; successful partial extension copying returns Segmented/public NeedMoreData. Buffer-bound/consistency or feeding failures may instead yield Unsupported or Stop. Allocation alone is not a completed CH or a guarantee of NeedMoreData.

Sources: `processor/src/ITLSParser.hpp:60` / `IClientHelloParser::Status`; `processor/src/Processor.cpp:1456` / `Processor::processClientHello`; `processor/src/Processor.cpp:1464` / `Processor::processClientHello`; `processor/src/Processor.cpp:1474` / `Processor::processClientHello`; `processor/src/Processor.cpp:971` / `Processor::processNewRecord`; `processor/src/Processor.cpp:1019` / `Processor::processNewRecord`; `processor/src/Processor.cpp:1101` / `Processor::processExtensions`.

### P3-PARSE-005 | IClientHelloParser::Status::Failure

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** IClientHelloParser::Status::Failure returned by the corresponding internal parser call; conditional translation is detailed below.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Internal CH parser Failure falls through the non-Complete handling to ClientHelloBodyInvalid/Error: the record-level and segmented-prefix/body exceptions test incomplete statuses, not Failure. processNewRecord propagates Error, translated to public Stop. It does not start CH extension continuation for this status.

Sources: `processor/src/ITLSParser.hpp:60` / `IClientHelloParser::Status`; `processor/src/Processor.cpp:1456` / `Processor::processClientHello`; `processor/src/Processor.cpp:1512` / `Processor::processClientHello`; `processor/src/Processor.cpp:210` / `Processor::processRecord`.

### P3-PARSE-006 | IExtensionsParser::Status::Complete

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** IExtensionsParser::Status::Complete returned by the corresponding internal parser call; conditional translation is detailed below.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Internal extension parser Complete is necessary but not sufficient for acceptance. parseAllExtensions also requires consumed bytes to match getSingleExtensionTotalLength(); mismatch becomes ExtensionParsingFailure/Error/public Stop. A valid extension is inserted into the locator array; capacity failure returns local StopProcessing without a dedicated error. Early-data and SNI handling can add facts or fail. Successful iteration advances offset/remaining length; only completion of the entire loop returns ContinueProcessing. Sorting and fingerprint feeding follow and can still fail.

Sources: `processor/src/ITLSParser.hpp:96` / `IExtensionsParser::Status`; `processor/src/Processor.cpp:1361` / `Processor::parseAllExtensions`; `processor/src/Processor.cpp:1383` / `Processor::parseAllExtensions`; `processor/src/Processor.cpp:1392` / `Processor::parseAllExtensions`; `processor/src/Processor.cpp:1159` / `Processor::processExtensions`.

### P3-PARSE-007 | IExtensionsParser::Status::IncompleteExtensionTypeField

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** IExtensionsParser::Status::IncompleteExtensionTypeField returned by the corresponding internal parser call; conditional translation is detailed below.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Internal extension parser non-Complete status. parseAllExtensions assigns ExtensionParsingFailure and returns Error for this status; the explicit Failure branch and the other non-Complete branch have the same outcome. There is no per-extension continuation started here. The new-record and CH-continuation callers propagate the error (the latter deallocates its continuation buffer); processRecord translates it to public Stop.

Sources: `processor/src/ITLSParser.hpp:96` / `IExtensionsParser::Status`; `processor/src/Processor.cpp:1361` / `Processor::parseAllExtensions`; `processor/src/Processor.cpp:1371` / `Processor::parseAllExtensions`; `processor/src/Processor.cpp:1159` / `Processor::processExtensions`; `processor/src/Processor.cpp:455` / `Processor::processSegmentedClientHelloContinuation`; `processor/src/Processor.cpp:210` / `Processor::processRecord`.

### P3-PARSE-008 | IExtensionsParser::Status::IncompleteExtensionLengthField

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** IExtensionsParser::Status::IncompleteExtensionLengthField returned by the corresponding internal parser call; conditional translation is detailed below.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Internal extension parser non-Complete status. parseAllExtensions assigns ExtensionParsingFailure and returns Error for this status; the explicit Failure branch and the other non-Complete branch have the same outcome. There is no per-extension continuation started here. The new-record and CH-continuation callers propagate the error (the latter deallocates its continuation buffer); processRecord translates it to public Stop.

Sources: `processor/src/ITLSParser.hpp:96` / `IExtensionsParser::Status`; `processor/src/Processor.cpp:1361` / `Processor::parseAllExtensions`; `processor/src/Processor.cpp:1371` / `Processor::parseAllExtensions`; `processor/src/Processor.cpp:1159` / `Processor::processExtensions`; `processor/src/Processor.cpp:455` / `Processor::processSegmentedClientHelloContinuation`; `processor/src/Processor.cpp:210` / `Processor::processRecord`.

### P3-PARSE-009 | IExtensionsParser::Status::IncompleteExtensionData

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** IExtensionsParser::Status::IncompleteExtensionData returned by the corresponding internal parser call; conditional translation is detailed below.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Internal extension parser non-Complete status. parseAllExtensions assigns ExtensionParsingFailure and returns Error for this status; the explicit Failure branch and the other non-Complete branch have the same outcome. There is no per-extension continuation started here. The new-record and CH-continuation callers propagate the error (the latter deallocates its continuation buffer); processRecord translates it to public Stop.

Sources: `processor/src/ITLSParser.hpp:96` / `IExtensionsParser::Status`; `processor/src/Processor.cpp:1361` / `Processor::parseAllExtensions`; `processor/src/Processor.cpp:1371` / `Processor::parseAllExtensions`; `processor/src/Processor.cpp:1159` / `Processor::processExtensions`; `processor/src/Processor.cpp:455` / `Processor::processSegmentedClientHelloContinuation`; `processor/src/Processor.cpp:210` / `Processor::processRecord`.

### P3-PARSE-010 | IExtensionsParser::Status::Failure

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** IExtensionsParser::Status::Failure returned by the corresponding internal parser call; conditional translation is detailed below.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** Internal extension parser non-Complete status. parseAllExtensions assigns ExtensionParsingFailure and returns Error for this status; the explicit Failure branch and the other non-Complete branch have the same outcome. There is no per-extension continuation started here. The new-record and CH-continuation callers propagate the error (the latter deallocates its continuation buffer); processRecord translates it to public Stop.

Sources: `processor/src/ITLSParser.hpp:96` / `IExtensionsParser::Status`; `processor/src/Processor.cpp:1361` / `Processor::parseAllExtensions`; `processor/src/Processor.cpp:1371` / `Processor::parseAllExtensions`; `processor/src/Processor.cpp:1159` / `Processor::processExtensions`; `processor/src/Processor.cpp:455` / `Processor::processSegmentedClientHelloContinuation`; `processor/src/Processor.cpp:210` / `Processor::processRecord`.

### P3-PARSE-011 | ParsingStatus vocabulary

**Authority:** CODE-VERIFIED.

**TCP producer/trigger:** ParsingStatus vocabulary returned by the corresponding internal parser call; conditional translation is detailed below.

**Evidence nature:** Software outcome/control or declared vocabulary; not an independent observed TLS message.

**Current fact:** ParsingStatus has exactly Complete and Failure. Incomplete outcomes exist in the specialized ClientHello/extension status enums, not this enum. Non-Complete TLS record/handshake/cipher parsing becomes specific stored errors in Processor, not automatically NeedMoreData.

Sources: `processor/src/ParsingStatus.hpp:17` / `ParsingStatus`; `processor/src/Processor.cpp:1542` / `Processor::processTlsRecord`; `processor/src/Processor.cpp:1527` / `Processor::processHandshake`; `processor/src/Processor.cpp:1422` / `Processor::processCiphers`.

## Corrections and retained findings

V5 closes the identified inventory issues: per-item triggers replace generic category placeholders; None/Partial/Complete and RecordParsed are separated; continuation delivery is conditional on final guards; SNI error predicates are explicit; buffer-preparation failure is not equated with memory exhaustion; ClientHelloData reference ownership and count representation are explicit; session-state lifetime and actual resource bounds are documented. All 131 IDs and prior source references remain.

Retained: conditional internal-status translation; nested cipher soft-stop propagation; Complete-before-capacity-failure; shared-viewer resume freshness risks; repeated CH callback possibility; packet-context multiple-CH guard; final-suite digest omission; raw QUIC transport-parameter hashing. These are current-code findings, not code repairs or approved QUIC behavior.

## Open questions and limits

- Q-FP: required QUIC fingerprint content/normalization remains a product decision. Existing code does not settle it.
- Q-EXT: external consumer field reads/retention and upstream Session/DPFrame contracts are not proven by this module. Phase 1 claims about external consumers remain PRIOR-REPORT unless their source is supplied and checked. This does not block starting the matrix.
- Q-RUNTIME: static interleaving/callback/digest findings are not measured production occurrences. No compilation, integration test or runtime validation was performed.
- Phase 2 is preserved, not reopened. Any contract-impacting contradiction found in Step 3 requires an exact clause, conflicting evidence and focused disposition, not silent policy replacement.

## Source digest appendix

- `common/include/TLSAlert.hpp`: bundle start line 273; SHA-256 `af9c4fa72b9344ac92ee6ae22db2f86c5fbe4f4e92d8e0f4614bcfc1d55c7058`.
- `common/include/TLSData.hpp`: bundle start line 320; SHA-256 `eb0142e48a7a04307604479e71c844ce9eada6d29b7861ee1d49cbc94cb96e1e`.
- `context/engine/src/Factory.cpp`: bundle start line 1467; SHA-256 `6af50d621c8df6b47c06f64567aa01f9d86a7d4e955f3f6c2b820c32e2f9065e`.
- `extension/include/TLSSessionExtension.hpp`: bundle start line 2658; SHA-256 `db64040052aad7c4f45085aeca2f76f4efeacf6d2b34a08a3387202a840d3452`.
- `extension/include/TLSSessionExtensionTable.hpp`: bundle start line 2775; SHA-256 `c3f21dd13e1eaaedf677fb47108190e58d1a728d3acc7cff4b5c559386502c97`.
- `packet-flow/include/ClientHelloData.hpp`: bundle start line 3030; SHA-256 `45646a5980a73892ab5903fc3d81342976b287703074fa46255e0e72ec046b3f`.
- `packet-flow/include/ITlsListener.hpp`: bundle start line 3085; SHA-256 `4f05ee3a61666d05448c8bc3577034f89508b9b9a9f553f556b227d0a55150f8`.
- `packet-flow/include/TLSFeatureVerdict.hpp`: bundle start line 3221; SHA-256 `743e9aa78ab2077fc800d1ad2c737d6a9900f3b9424a8ffa8b6a403321a7ea8c`.
- `packet-flow/include/TLSRecordContext.hpp`: bundle start line 3289; SHA-256 `20a20fe84358f74c2209508099a162e44d89c66725de58f63012ea650d2bbddc`.
- `packet-flow/src/TLSFlowConductor.cpp`: bundle start line 3320; SHA-256 `b5e4281bb1cc0e2109ab077a92e792ce90bdbffdbdf144bbc8b18259282f15ff`.
- `packet-flow/src/TLSFlowConductor.hpp`: bundle start line 3907; SHA-256 `5820f7b6362b63b05cc4a00012e8ab7fd7bb632b567fca19a67a24416f3eeebf`.
- `processor/include/Definitions.hpp`: bundle start line 4190; SHA-256 `69ae45a95914e3feb05f384097f11a67a34157e0c841da3a07cb825e640b18bf`.
- `processor/include/IClientHelloDataViewer.hpp`: bundle start line 4267; SHA-256 `65bc73a1bdab3660e87405e66d2fdcbacaa221732ce1889c70f9e0ad695bf152`.
- `processor/include/IParsingErrorViewer.hpp`: bundle start line 4394; SHA-256 `2dd454b1d9b37b35b460579b8b3c4a7724a062aab9d8d845eb186d7f5baf2ac1`.
- `processor/include/IProcessor.hpp`: bundle start line 4418; SHA-256 `1cd56e2f5bbb9920e175c98b44414c679c6e7cba81ac1e275b98a726a0cd3a1f`.
- `processor/include/IRecordsDataViewer.hpp`: bundle start line 4490; SHA-256 `dd028864167a3a8672a0d48915370250fea74e0da915a3c9b2fb0fb86c9a2876`.
- `processor/include/ParsingError.hpp`: bundle start line 4517; SHA-256 `88b2ccc6e7190ba1c7aacff0211ef0de6de539368001cac1a92ef5df5d9bd777`.
- `processor/include/PayloadParams.hpp`: bundle start line 4602; SHA-256 `6ec6c6543637d8eb8ae5bb75d74974fbdefd03463e869d20c4f9d177f586b17f`.
- `processor/include/Record.hpp`: bundle start line 4668; SHA-256 `01648651771d7bf71429ac8d1360a80d7b835bcd176c4818e5d7a099571be17c`.
- `processor/src/ExtensionsSorting.hpp`: bundle start line 4725; SHA-256 `12998c6f4ebffafa442f96224477c2231723fc8e7d0ecaf7c38b6b52007e90c2`.
- `processor/src/ITLSParser.hpp`: bundle start line 4920; SHA-256 `a31d1b6811d2999849795b686d1865da2f375c38c904c9d459638552470ebc9f`.
- `processor/src/Md5Digest.cpp`: bundle start line 5239; SHA-256 `41307878d7530d8a8ee85a94f0804bcb76dda6fb1ba81601062dd0f09b6be3df`.
- `processor/src/Md5Digest.hpp`: bundle start line 5279; SHA-256 `087752e60bdb578f5984a14ebfa9fe07dde40fc2a7d71525f2393f92d8f5e656`.
- `processor/src/ParsingStatus.hpp`: bundle start line 5328; SHA-256 `6e9de4d55c4a0cf0f7c9b3ba609966c73d819d3425309d2c538fb3eae2e3cf9f`.
- `processor/src/Processor.cpp`: bundle start line 5355; SHA-256 `c27450c00cfc946647ca81f966fb8c0bd47e876965ff5b7fd3ed92b3b51b8750`.
- `processor/src/Processor.hpp`: bundle start line 7025; SHA-256 `3ac11ef4c4f7db0994c4350b734b007b14ad76cb04bae41546007dea84b83759`.
- `processor/src/SegmentBuffer.hpp`: bundle start line 7609; SHA-256 `7a84d8f244a9741bc8c3bd965c7d6e3b1b959d35aefa68558a9abed3df86a351`.
- `processor/src/SegmentBufferManager.cpp`: bundle start line 7775; SHA-256 `08112c60073c4b935fbdc77db365c327d07081864cc3ff2e8619e8d5e160c20a`.
- `processor/src/SegmentBufferManager.hpp`: bundle start line 7895; SHA-256 `a5467690662f8a5dd3b095bcbc24d181f5ac3d7ca7b114337d9101638a52319a`.

## Authority digests

- `tls-flow-quic-pre-design-work-plan-v5.md`: SHA-256 `55ea1536ac4913e3a4ce59cc717fc3f5e8752dcdddf51be66bed34b280c024fa`.
- `phase1-copilot-report.md`: SHA-256 `9c25e615a26c28f65ddc3a26ee61c9e18ce90212c9ee0f9ca0b0506c8b840a69`.
- `phase2-state-machine.md`: SHA-256 `b2d0ae9254ed6e96c643281bfc09302dd8c8360b9672ff16611055820f02de77`.
- `TLS-Flow-All-Code.txt`: SHA-256 `70f6f63926a6f9426033aec6903951cc804b2225b153d20d3a3b8e13d2808f5b`.
